package Logica;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.locks.ReentrantLock;

public class Logger {
    private static Logger instancia;
    private final String archivoLog;
    private final ReentrantLock lock;
    private final SimpleDateFormat formatoFecha;
    private final boolean mostrarEnConsola;
    // Niveles de log
    public enum Nivel {
        INFO, ADVERTENCIA, ERROR, SEGURIDAD
    }

    private Logger() {
        this.archivoLog = "sistema_login.log";
        this.lock = new ReentrantLock();
        this.formatoFecha = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        this.mostrarEnConsola = true;
        crearArchivoLogSiNoExiste();
    }

    public static Logger getInstancia() {
        if (instancia == null) {
            instancia = new Logger();
        }
        return instancia;
    }

    private void crearArchivoLogSiNoExiste() {
        try {
            File archivo = new File(archivoLog);
            if (!archivo.exists()) {
                archivo.createNewFile();
                log(Nivel.INFO, "Sistema", "Archivo de log creado - Sistema de Login iniciado");
            }
        } catch (IOException e) {
            System.err.println("Error creando archivo de log: " + e.getMessage());
        }
    }

    public void log(Nivel nivel, String usuario, String mensaje) {
        lock.lock();
        try {
            String timestamp = formatoFecha.format(new Date());
            String entradaLog = String.format("[%s] [%s] [%s] [%s] %s%n", 
                timestamp, nivel, usuario, Thread.currentThread().getName(), mensaje);

            // Escribir en archivo
            try (FileWriter fw = new FileWriter(archivoLog, true);
                 BufferedWriter bw = new BufferedWriter(fw);
                 PrintWriter out = new PrintWriter(bw)) {
                out.print(entradaLog);
            } catch (IOException e) {
                System.err.println("Error escribiendo en log: " + e.getMessage());
            }
            if (mostrarEnConsola) {
                System.out.printf("[%s] [%s] [%s] %s%n", timestamp, nivel, usuario, mensaje);
            }

        } finally {
            lock.unlock();
        }
    }

    // Métodos específicos para diferentes tipos de eventos

    public void logCreacionUsuario(String administrador, String nuevoUsuario, String rol) {
        String mensaje = String.format("Usuario creado: %s con rol: %s", nuevoUsuario, rol);
        log(Nivel.INFO, administrador, mensaje);
    }

    public void logModificacionRol(String administrador, String usuario, String rolAnterior, String rolNuevo) {
        String mensaje = String.format("Rol modificado: %s - De: %s a: %s", usuario, rolAnterior, rolNuevo);
        log(Nivel.INFO, administrador, mensaje);
    }

    public void logAccionSistema(String usuario, String accion, String recurso) {
        String mensaje = String.format("Acción: %s - Recurso: %s", accion, recurso);
        log(Nivel.INFO, usuario, mensaje);
    }

    public void logError(String usuario, String modulo, String error) {
        String mensaje = String.format("Error en módulo %s: %s", modulo, error);
        log(Nivel.ERROR, usuario, mensaje);
    }

    public void logCierreSesion(String usuario, String duracionSesion) {
        String mensaje = String.format("Sesión finalizada - Duración: %s", duracionSesion);
        log(Nivel.INFO, usuario, mensaje);
    }

    // obtener logs
    public List<String> obtenerUltimosLogsComoLista(int cantidad){
        List<String> logs = new ArrayList<>();
        lock.lock();
        try{
            File archivo = new File(archivoLog);
            if (!archivo.exists()){
                return logs;
            }
            try (BufferedReader br = new BufferedReader(new FileReader(archivoLog))) {
                String linea;
                List<String> todasLineas = new ArrayList<>();

                while ((linea = br.readLine()) != null) {
                    todasLineas.add(linea);
                }

                // Obtener las últimas 'cantidad' líneas
                int inicio = Math.max(0, todasLineas.size() - cantidad);
                for (int i = inicio; i < todasLineas.size(); i++) {
                    logs.add(todasLineas.get(i));
                }

            } catch (IOException e) {
                logError("Sistema", "Logger", "Error leyendo logs: " + e.getMessage());
            }
        } finally{
            lock.unlock();
        }
        return logs;
    }
}