package Logica;

import Persistencia.UsuarioDAO;
import java.util.Map;
import java.util.HashMap;

public class SistemaLogin {
    private static SistemaLogin instancia;
    private Map<String, Usuario> usuarios;
    private Map<String, String> tokensActivos; // token -> username
    private FabricaRoles fabricaRoles;
    private SistemaAutorizacion sistemaAutorizacion;
    private Logger logger;
    private UsuarioDAO usuarioDAO;
    private TokenManager jwtManager;
    private int intentosFallidos;

    private SistemaLogin() {
        this.fabricaRoles = new FabricaRoles();
        this.sistemaAutorizacion = new SistemaAutorizacion();
        this.logger = Logger.getInstancia();
        this.usuarioDAO = new UsuarioDAO();
        this.jwtManager = TokenManager.getInstancia();
        this.tokensActivos = new HashMap<>();
        this.intentosFallidos = 0;

        cargarUsuariosDesdeBD();
    }

    public static SistemaLogin getInstancia() {
        if (instancia == null) {
            instancia = new SistemaLogin();
        }
        return instancia;
    }

    private void cargarUsuariosDesdeBD() {
        try {
            this.usuarios = usuarioDAO.obtenerTodosUsuarios();
            logger.log(Logger.Nivel.INFO, "Sistema",
                    "Usuarios cargados desde BD: " + usuarios.size() + " usuarios");
        } catch (Exception e) {
            System.err.println("Error cargando usuarios desde BD: " + e.getMessage());
            this.usuarios = new HashMap<>();
        }
    }

    public AuthResult autenticar(String nombreUsuario, String clave) {
        Usuario usuario = usuarios.get(nombreUsuario);
        if(usuario != null && usuario.validarClave(clave)) {
            intentosFallidos = 0;
            // Generar token JWT
            String token = jwtManager.generarToken(
                    usuario.getNombreUsuario(),
                    usuario.getRol().getNombre(),
                    usuario.getId()
            );

            // Guardar token en usuario y en mapa de tokens activos
            usuario.setToken(token);
            usuario.setFechaExpiracionToken(jwtManager.obtenerExpiracionDeToken(token));
            tokensActivos.put(token, usuario.getNombreUsuario());

            logger.log(Logger.Nivel.INFO, nombreUsuario, "Token JWT generado");

            return new AuthResult(true, "Autenticación exitosa", token, usuario);
        } else {
            intentosFallidos++;
            logger.log(Logger.Nivel.SEGURIDAD, usuario.getNombreUsuario(),
                    "Contraseña incorrecta");
            if (intentosFallidos >= 3) {
                logger.log(Logger.Nivel.ADVERTENCIA, nombreUsuario,
                        "Múltiples intentos fallidos de login: " + intentosFallidos);
            }
            return new AuthResult(false, "Credenciales incorrectas", null, null);
        }
    }

    public boolean validarToken(String token) {
        if (token == null || token.trim().isEmpty()) {
            return false;
        }
        // Verificar si el token está en lista de activos
        if (!tokensActivos.containsKey(token)) {
            logger.log(Logger.Nivel.SEGURIDAD, "Sistema",
                    "Intento de uso de token no registrado: " + token);
            return false;
        }
        // Validar el token JWT
        boolean esValido = jwtManager.validarToken(token);
        if (!esValido) {
            // Remover token inválido
            tokensActivos.remove(token);
            logger.log(Logger.Nivel.SEGURIDAD, "Sistema",
                    "Token removido por inválido: " + token);
        }
        return esValido;
    }

    public Usuario obtenerUsuarioDeToken(String token) {
        if (!validarToken(token)) {
            return null;
        }
        String username = tokensActivos.get(token);
        return usuarios.get(username);
    }

    public String refrescarToken(String tokenViejo) {
        if (!validarToken(tokenViejo)) {
            throw new SecurityException("Token no válido para refrescar");
        }
        Usuario usuario = obtenerUsuarioDeToken(tokenViejo);
        if (usuario == null) {
            throw new SecurityException("Usuario no encontrado para el token");
        }
        // Generar nuevo token
        String nuevoToken = jwtManager.generarToken(
                usuario.getNombreUsuario(),
                usuario.getRol().getNombre(),
                usuario.getId()
        );
        // Actualizar en el sistema
        tokensActivos.remove(tokenViejo);
        tokensActivos.put(nuevoToken, usuario.getNombreUsuario());
        usuario.setToken(nuevoToken);
        usuario.setFechaExpiracionToken(jwtManager.obtenerExpiracionDeToken(nuevoToken));
        logger.log(Logger.Nivel.INFO, usuario.getNombreUsuario(), "Token refrescado");
        return nuevoToken;
    }

    public void cerrarSesion(String token) {
        if (token != null && tokensActivos.containsKey(token)) {
            String username = tokensActivos.get(token);
            tokensActivos.remove(token);

            Usuario usuario = usuarios.get(username);
            if (usuario != null) {
                usuario.setToken(null);
                usuario.setFechaExpiracionToken(null);
            }

            logger.log(Logger.Nivel.INFO, username, "Sesión cerrada - Token invalidado");
        }
    }

    public void registrarUsuario(Usuario usuario) {
        try {
            usuarios.put(usuario.getNombreUsuario(), usuario);
            usuarioDAO.guardarUsuario(usuario);
            logger.logCreacionUsuario("Sistema", usuario.getNombreUsuario(),
                    usuario.getRol().getNombre());
        } catch (Exception e) {
            System.err.println("Error registrando usuario: " + e.getMessage());
        }
    }

    // Clase interna para resultado de autenticación
    public static class AuthResult {
        private final boolean exitoso;
        private final String mensaje;
        private final String token;
        private final Usuario usuario;

        public AuthResult(boolean exitoso, String mensaje, String token, Usuario usuario) {
            this.exitoso = exitoso;
            this.mensaje = mensaje;
            this.token = token;
            this.usuario = usuario;
        }

        // Getters
        public boolean isExitoso() { return exitoso; }
        public String getMensaje() { return mensaje; }
        public String getToken() { return token; }
        public Usuario getUsuario() { return usuario; }
    }

    public void crearUsuarioConRol(String nombreUsuario, String clave, String nombreRol) {
        try {
            Rol rol = fabricaRoles.obtenerRolPorNombre(nombreRol);
            if (rol != null) {
                Usuario usuario = new Usuario(nombreUsuario, clave, rol);
                registrarUsuario(usuario);
            } else {
                logger.log(Logger.Nivel.ERROR, "Sistema",
                        "No se pudo crear usuario. Rol no encontrado: " + nombreRol);
            }
        } catch (Exception e) {
            System.err.println("Error creando usuario: " + e.getMessage());
        }
    }

    public void mostrarUsuarios() {
        System.out.println("\n=== USUARIOS REGISTRADOS ===");
        for (Usuario usuario : usuarios.values()) {
            System.out.println( usuario.getNombreUsuario() +
                    " - Rol: " + usuario.getRol().getNombre());
        }
        System.out.println("Total: " + usuarios.size() + " usuarios");
    }

    public Map<String, Usuario> obtenerTodosUsuarios() {
        return new HashMap<>(usuarios); // Retorna una copia del mapa de usuarios
    }


    public FabricaRoles getFabricaRoles() {
        return fabricaRoles;
    }

    public boolean existeUsuario(String nombreUsuario) {
        return usuarios.containsKey(nombreUsuario);
    }
}