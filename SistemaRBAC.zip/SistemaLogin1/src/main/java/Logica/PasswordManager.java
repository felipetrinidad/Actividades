package Logica;

import org.mindrot.jbcrypt.BCrypt;

public class PasswordManager {
    private static PasswordManager instancia;

    private PasswordManager() {}

    public static PasswordManager getInstancia() {
        if (instancia == null) {
            instancia = new PasswordManager();
        }
        return instancia;
    }

    public String encriptarPassword(String password) {
        return BCrypt.hashpw(password, BCrypt.gensalt(12));
    }

    public boolean verificarPassword(String password, String hash) {
        try {
            return BCrypt.checkpw(password, hash);
        } catch (Exception e) {
            Logger.getInstancia().log(Logger.Nivel.ERROR, "Sistema",
                    "Error verificando password: " + e.getMessage());
            return false;
        }
    }

    public boolean esPasswordFuerte(String password) {
        if (password == null || password.length() < 8) {
            return false;
        }
        boolean tieneMayuscula = false;
        boolean tieneMinuscula = false;
        boolean tieneNumero = false;
        boolean tieneEspecial = false;
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) tieneMayuscula = true;
            if (Character.isLowerCase(c)) tieneMinuscula = true;
            if (Character.isDigit(c)) tieneNumero = true;
            if (!Character.isLetterOrDigit(c)) tieneEspecial = true;
        }
        return tieneMayuscula && tieneMinuscula && tieneNumero && tieneEspecial;
    }
}