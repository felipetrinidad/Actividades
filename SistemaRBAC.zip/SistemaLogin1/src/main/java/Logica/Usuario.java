package Logica;

import java.util.Date;

public class Usuario {
    private int id;
    private String nombreUsuario;
    private String clave; // hasheada
    private Rol rol;
    private String token; // Token JWT actual
    private Date fechaExpiracionToken;

    public Usuario() {}

    public Usuario(String nombreUsuario, String clave, Rol rol) {
        this.nombreUsuario = nombreUsuario;
        setClave(clave);
        this.rol = rol;
    }

    public Usuario(int id, String nombreUsuario, String clave, Rol rol) {
        this(nombreUsuario, clave, rol);
        this.id = id;
    }

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNombreUsuario() { return nombreUsuario; }
    public void setNombreUsuario(String nombreUsuario) { this.nombreUsuario = nombreUsuario; }

    public String getClave() { return clave; }
    public void setClave(String clave) {
        this.clave = PasswordManager.getInstancia().encriptarPassword(clave);
    }

    public void setClaveHash(String hash) {
        this.clave = hash;
    }

    public Rol getRol() { return rol; }
    public void setRol(Rol rol) { this.rol = rol; }

    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }

    public void setFechaExpiracionToken(Date fechaExpiracionToken) {
        this.fechaExpiracionToken = fechaExpiracionToken;
    }

    public boolean validarClave(String entradaClave) {
        return PasswordManager.getInstancia().verificarPassword(entradaClave, this.clave);
    }

    public boolean tienePermiso(String codigoPermiso) {
        return rol != null && rol.tienePermiso(codigoPermiso);
    }



    @Override
    public String toString() {
        return nombreUsuario + " (" + (rol != null ? rol.getNombre() : "Sin rol") + ")";
    }
}