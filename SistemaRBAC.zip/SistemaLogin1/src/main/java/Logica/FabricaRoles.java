package Logica;

import Persistencia.RolDAO;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class FabricaRoles{
    private RolDAO rolDAO;
    private FabricaPermisos fabricaPermisos;

    public FabricaRoles(){
        this.rolDAO = new RolDAO();
        this.fabricaPermisos = FabricaPermisos.getInstancia();
        inicializarRolesBase();
    }

    private void inicializarRolesBase(){
        // Solo crear roles base si no existen
        if (rolDAO.obtenerTodosRoles().isEmpty()){
            crearRolPersonal("Personal", "Rol básico para personal operativo");
            crearRolJefeArea("Jefe de Área", "Rol para jefes de área/departamento");
            crearRolGerente("Gerente", "Rol para gerentes de área");
            crearRolDirector("Director", "Rol para directivos de la organización");
            crearRolSupervisor("Supervisor", "Rol para supervisores de procesos");
            crearRolAdministradorSistema("Administrador del Sistema", "Rol con acceso total al sistema");

            Logger.getInstancia().log(Logger.Nivel.INFO, "Sistema", "Roles base inicializados");
        }
    }

    public Rol crearRolPersonalizado(String nombre, String descripcion, Set<String> codigosPermisos){
        Rol rol = new Rol(nombre, descripcion);
        
        for (String codigo : codigosPermisos){
            Permiso permiso = fabricaPermisos.obtenerPermiso(codigo);
            if (permiso != null) {
                rol.agregarPermiso(permiso);
            }
        }
        rolDAO.guardarRol(rol);
        Logger.getInstancia().log(Logger.Nivel.INFO, "Sistema", 
            "Rol personalizado creado: " + nombre + " con " + codigosPermisos.size() + " permisos");
        return rol;
    }
    public Rol crearRolPersonal(String nombre, String descripcion){
        Set<String> permisos = new HashSet<>(Arrays.asList("LECTURA"));
        return crearRolPersonalizado(nombre, descripcion, permisos);
    }

    public Rol crearRolJefeArea(String nombre, String descripcion){
        Set<String> permisos = new HashSet<>(Arrays.asList("LECTURA", "EDICION"));
        return crearRolPersonalizado(nombre, descripcion, permisos);
    }

    public Rol crearRolGerente(String nombre, String descripcion){
        Set<String> permisos = new HashSet<>(Arrays.asList("LECTURA", "EDICION", "APROBACION"));
        return crearRolPersonalizado(nombre, descripcion, permisos);
    }

    public Rol crearRolDirector(String nombre, String descripcion){
        Set<String> permisos = new HashSet<>(Arrays.asList("LECTURA", "EDICION", "APROBACION", "DECISION"));
        return crearRolPersonalizado(nombre, descripcion, permisos);
    }

    public Rol crearRolSupervisor(String nombre, String descripcion){
        Set<String> permisos = new HashSet<>(Arrays.asList("LECTURA", "CONTROL"));
        return crearRolPersonalizado(nombre, descripcion, permisos);
    }

    public Rol crearRolAdministradorSistema(String nombre, String descripcion){
        Set<String> permisos = new HashSet<>(Arrays.asList("GESTION_TOTAL"));
        return crearRolPersonalizado(nombre, descripcion, permisos);
    }

    public Rol obtenerRolPorNombre(String nombre){
        return rolDAO.obtenerRolPorNombre(nombre);
    }

    public Set<Rol> obtenerTodosRoles(){
        return rolDAO.obtenerTodosRoles();
    }
}