package Logica;

import java.util.*;

public class Rol {
    private int id;
    private String nombre;
    private String descripcion;
    private Set<Permiso> permisos;

    public Rol() {
        this.permisos = new HashSet<>();
    }

    public Rol(String nombre, String descripcion) {
        this();
        this.nombre = nombre;
        this.descripcion = descripcion;
    }
    public Rol(int id, String nombre, String descripcion) {
        this(nombre, descripcion);
        this.id = id;
    }

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public Set<Permiso> getPermisos() { return new HashSet<>(permisos); }
    public void setPermisos(Set<Permiso> permisos) { this.permisos = new HashSet<>(permisos); }

    // Métodos para gestión de permisos
    public void agregarPermiso(Permiso permiso) {
        this.permisos.add(permiso);
    }

    public void removerPermiso(Permiso permiso) {
        this.permisos.remove(permiso);
    }

    public boolean tienePermiso(String codigoPermiso) {
        if (permisos.stream().anyMatch(p -> p.getCodigo().equals("GESTION_TOTAL"))) {
            return true;
        }
        return permisos.stream().anyMatch(p -> p.getCodigo().equals(codigoPermiso));
    }

    @Override
    public String toString() {
        return nombre + " - " + descripcion + " [Permisos: " + permisos.size() + "]";
    }
}
