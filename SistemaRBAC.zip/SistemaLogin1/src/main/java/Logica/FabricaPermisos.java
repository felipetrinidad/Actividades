package Logica;

import Persistencia.PermisoDAO;
import java.util.Set;
public class FabricaPermisos {
    private static FabricaPermisos instancia;
    private PermisoDAO permisoDAO;

    private FabricaPermisos() {
        this.permisoDAO = new PermisoDAO();
        inicializarPermisosBase();
    }

    public static FabricaPermisos getInstancia() {
        if (instancia == null) {
            instancia = new FabricaPermisos();
        }
        return instancia;
    }

    private void inicializarPermisosBase() {
        // Solo crear permisos si no existen
        if (permisoDAO.obtenerTodosPermisos().isEmpty()) {
            registrarPermiso("LECTURA", "Permiso de lectura básica", "ACCESO");
            registrarPermiso("EDICION", "Permiso de edición y modificación", "ACCESO");
            registrarPermiso("APROBACION", "Permiso para aprobar solicitudes", "WORKFLOW");
            registrarPermiso("DECISION", "Permiso para decisiones estratégicas", "DIRECCION");
            registrarPermiso("CONTROL", "Permiso de supervisión y control", "CONTROL");
            registrarPermiso("GESTION_TOTAL", "Permiso de administración completa del sistema", "ADMINISTRACION");

            Logger.getInstancia().log(Logger.Nivel.INFO, "Sistema", "Permisos base inicializados");
        }
    }

    public Permiso registrarPermiso(String codigo, String descripcion, String categoria) {
        Permiso permiso = new Permiso(codigo, descripcion, categoria);
        permisoDAO.guardarPermiso(permiso);
        return permiso;
    }

    public Permiso obtenerPermiso(String codigo) {
        return permisoDAO.obtenerPermiso(codigo);
    }

    public Set<Permiso> obtenerTodosPermisos() {
        return permisoDAO.obtenerTodosPermisos();
    }
}
