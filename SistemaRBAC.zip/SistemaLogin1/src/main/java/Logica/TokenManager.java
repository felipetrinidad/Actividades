package Logica;

import io.jsonwebtoken.*;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class TokenManager {
    private static TokenManager instancia;
    private final SecretKey claveSecreta;
    private final long tiempoExpiracion = 1000 * 60 * 3;
    private final JwtParser parser;

    private TokenManager() {
        String claveSecretaString = "MiClaveSecretaAbcdefghijklmnopqr";
        this.claveSecreta = new SecretKeySpec(claveSecretaString.getBytes(), SignatureAlgorithm.HS256.getJcaName());
        this.parser = Jwts.parserBuilder().setSigningKey(claveSecreta).build();
    }

    public static TokenManager getInstancia() {
        if (instancia == null) {
            instancia = new TokenManager();
        }
        return instancia;
    }

    public String generarToken(String username, String rol, int userId) {
        Map<String, Object> claims = new HashMap<>();
        claims.put("rol", rol);
        claims.put("userId", userId);
        claims.put("username", username);

        Date ahora = new Date();
        Date expiracion = new Date(ahora.getTime() + tiempoExpiracion);

        return Jwts.builder()
                .setClaims(claims)
                .setSubject(username)
                .setIssuedAt(ahora)
                .setExpiration(expiracion)
                .signWith(claveSecreta)
                .compact();
    }

    public boolean validarToken(String token) {
        try {
            parser.parseClaimsJws(token);
            return true;
        } catch (JwtException | IllegalArgumentException e) {
            Logger.getInstancia().log(Logger.Nivel.SEGURIDAD, "Sistema",
                    "Token inválido: " + e.getMessage());
            return false;
        }
    }

    public String obtenerUsernameDeToken(String token) {
        Claims claims = parser.parseClaimsJws(token).getBody();
        return claims.getSubject();
    }

    public String obtenerRolDeToken(String token) {
        Claims claims = parser.parseClaimsJws(token).getBody();
        return claims.get("rol", String.class);
    }

    public int obtenerUserIdDeToken(String token) {
        Claims claims = parser.parseClaimsJws(token).getBody();
        return claims.get("userId", Integer.class);
    }

    public Date obtenerExpiracionDeToken(String token) {
        Claims claims = parser.parseClaimsJws(token).getBody();
        return claims.getExpiration();
    }

    public boolean estaPorExpirar(String token) {
        Date expiracion = obtenerExpiracionDeToken(token);
        long tiempoRestante = expiracion.getTime() - System.currentTimeMillis();
        return tiempoRestante < (1000 * 60);
    }
}