package Logica;

public class Permiso{
    private String codigo;
    private String descripcion;
    private String categoria;

    public Permiso(String codigo, String descripcion, String categoria) {
        this.codigo = codigo;
        this.descripcion = descripcion;
        this.categoria = categoria;
    }

    // Getters y Setters
    public String getCodigo(){ return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }

    public String getDescripcion(){ return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public String getCategoria(){ return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }

    @Override
    public boolean equals(Object o){
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Permiso permiso = (Permiso) o;
        return codigo.equals(permiso.codigo);
    }

    @Override
    public int hashCode(){
        return codigo.hashCode();
    }

    @Override
    public String toString(){
        return codigo + " - " + descripcion + " (" + categoria + ")";
    }
}
