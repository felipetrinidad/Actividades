package Logica;

import java.util.*;

public class Main {

    private static Usuario usuarioActual = null;
    private static String tokenActual = null;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        SistemaLogin sistema = SistemaLogin.getInstancia();
        Logger logger = Logger.getInstancia();

        logger.log(Logger.Nivel.INFO, "Sistema", "Aplicación iniciada en modo consola");

        System.out.println("=".repeat(50));
        System.out.println("   SISTEMA DE LOGIN CON PERSISTENCIA SQLite");
        System.out.println("             MODO CONSOLA");
        System.out.println("=".repeat(50));

        boolean ejecutando = true;
        while (ejecutando) {
            if (usuarioActual == null) {
                // Menú cuando NO hay usuario logueado
                System.out.println("\nMENÚ PRINCIPAL (No autenticado)");
                System.out.println("1.Iniciar sesión");
                System.out.println("2. Registrarse");
                System.out.println("3. Salir");
                System.out.print("Seleccione una opción: ");
            } else {
                // Menú cuando SÍ hay usuario logueado
                System.out.println("\nMENÚ PRINCIPAL (Usuario: " + usuarioActual.getNombreUsuario() + ")");
                System.out.println("1. Ver información de usuario");
                System.out.println("2. Ver usuarios registrados");
                System.out.println("3. Crear nuevo usuario");
                System.out.println("4. Crear nuevo rol personalizado");
                System.out.println("5. Ver logs recientes");
                System.out.println("6. Ver estadísticas de log");
                System.out.println("7. Refrescar token");
                System.out.println("8. Ver información del token");
                System.out.println("9. Cerrar sesión");
                System.out.print("Seleccione una opción: ");
            }

            String opcion = scanner.nextLine();

            if (usuarioActual == null) {
                // Opciones sin autenticación
                switch (opcion) {
                    case "1":
                        realizarLogin(sistema, scanner, logger);
                        break;
                    case "2":
                        registrarUsuario(sistema, scanner, logger);
                        break;
                    case "3":
                        ejecutando = false;
                        logger.log(Logger.Nivel.INFO, "Sistema", "Aplicación finalizada por el usuario");
                        break;
                    default:
                        System.out.println(" Opción no válida");
                        logger.log(Logger.Nivel.ADVERTENCIA, "Sistema", "Opción de menú no válida: " + opcion);
                }
            } else {
                // Opciones con autenticación
                switch (opcion) {
                    case "1":
                        mostrarInformacionUsuario();
                        break;
                    case "2":
                        sistema.mostrarUsuarios();
                        break;
                    case "3":
                        crearNuevoUsuario(sistema, scanner, logger);
                        break;
                    case "4":
                        crearNuevoRolPersonalizado(sistema, scanner, logger);
                        break;
                    case "7":
                        refrescarToken(sistema, logger);
                        break;
                    case "8":
                        mostrarInformacionToken();
                        break;
                    case "9":
                        cerrarSesion(sistema, logger);
                        break;
                    default:
                        System.out.println("Opción no válida");
                        logger.log(Logger.Nivel.ADVERTENCIA, usuarioActual.getNombreUsuario(), "Opción de menú no válida: " + opcion);
                }
            }
        }

        scanner.close();
        System.out.println("\n Sesión terminada. ¡Hasta pronto!");
    }

    private static void realizarLogin(SistemaLogin sistema, Scanner scanner, Logger logger) {
        System.out.println("\nINICIO DE SESIÓN");
        System.out.print("Usuario: ");
        String usuario = scanner.nextLine();

        System.out.print("Contraseña: ");
        String clave = scanner.nextLine();

        long inicio = System.currentTimeMillis();
        SistemaLogin.AuthResult resultado = sistema.autenticar(usuario, clave);
        long fin = System.currentTimeMillis();

        String duracion = (fin - inicio) + "ms";
        logger.log(Logger.Nivel.INFO, usuario, "Tiempo de autenticación: " + duracion);

        if (resultado.isExitoso()) {
            usuarioActual = resultado.getUsuario();
            tokenActual = resultado.getToken();
            System.out.println("Login exitoso! Token generado.");
            logger.log(Logger.Nivel.INFO, usuario, "Login exitoso desde consola");

            // Mostrar información de autorización
//            sistema.autorizar(usuarioActual);
//            mostrarMenuPostLogin(scanner, logger);
        } else {
            System.out.println("ACCESO DENEGADO: " + resultado.getMensaje());
        }
    }

    private static void registrarUsuario(SistemaLogin sistema, Scanner scanner, Logger logger) {
        System.out.println("\nREGISTRO DE NUEVO USUARIO");
        System.out.print("Nombre de usuario: ");
        String nombreUsuario = scanner.nextLine();

        System.out.print("Contraseña: ");
        String clave = scanner.nextLine();

        System.out.print("Confirmar contraseña: ");
        String confirmarClave = scanner.nextLine();

        if (!clave.equals(confirmarClave)) {
            System.out.println("Las contraseñas no coinciden");
            return;
        }

        System.out.println("Roles disponibles: Asistente, Coordinador, Gerente, Administrador");
        System.out.print("Rol: ");
        String rol = scanner.nextLine();

        // Verificar si el usuario ya existe
        if (sistema.existeUsuario(nombreUsuario)) {
            System.out.println("El usuario ya existe");
            return;
        }

        // Verificar fortaleza de la contraseña
        if (!PasswordManager.getInstancia().esPasswordFuerte(clave)) {
            System.out.println("La contraseña no cumple los requisitos de seguridad:");
            System.out.println("   - Mínimo 8 caracteres");
            System.out.println("   - Al menos una mayúscula y una minúscula");
            System.out.println("   - Al menos un número");
            System.out.println("   - Al menos un símbolo");
            return;
        }

        try {
            sistema.crearUsuarioConRol(nombreUsuario, clave, rol);
            System.out.println("Usuario registrado exitosamente");
            logger.log(Logger.Nivel.INFO, "Sistema", "Nuevo usuario registrado: " + nombreUsuario + " con rol: " + rol);
        } catch (Exception e) {
            System.out.println("Error registrando usuario: " + e.getMessage());
            logger.log(Logger.Nivel.ERROR, "Sistema", "Error en registro: " + e.getMessage());
        }
    }

    private static void mostrarMenuPostLogin(Scanner scanner, Logger logger) {
        System.out.println("\n¿Qué deseas hacer ahora?");
        System.out.println("1. Simular acciones según permisos");
        System.out.println("2. Continuar al menú principal");
        System.out.print("Seleccione una opción: ");

        String opcion = scanner.nextLine();
        if (opcion.equals("1")) {
            simularAccionesConLogging(usuarioActual, scanner, logger);
        }
    }

    private static void mostrarInformacionUsuario() {
        System.out.println("\nINFORMACIÓN DEL USUARIO");
        System.out.println("Usuario: " + usuarioActual.getNombreUsuario());
        System.out.println("Rol: " + usuarioActual.getRol().getNombre());
        System.out.println("Descripción: " + usuarioActual.getRol().getDescripcion());
        System.out.println("Permisos:");
        for (Permiso permiso : usuarioActual.getRol().getPermisos()) {
            System.out.println("   • " + permiso.getCodigo() + " - " + permiso.getDescripcion());
        }
    }

    private static void crearNuevoUsuario(SistemaLogin sistema, Scanner scanner, Logger logger) {
        if (!validarToken()) return;

        System.out.println("\n👤 CREAR NUEVO USUARIO");
        System.out.print("Nombre de usuario: ");
        String nombreUsuario = scanner.nextLine();

        System.out.print("Contraseña: ");
        String clave = scanner.nextLine();

        System.out.print("Rol (Asistente/Coordinador/Gerente/Administrador): ");
        String rol = scanner.nextLine();

        sistema.crearUsuarioConRol(nombreUsuario, clave, rol);
        System.out.println("Usuario creado exitosamente");
    }

    private static void crearNuevoRolPersonalizado(SistemaLogin sistema, Scanner scanner, Logger logger) {
        if (!validarToken()) return;

        System.out.println("\nCREAR NUEVO ROL PERSONALIZADO");
        System.out.print("Nombre del rol: ");
        String nombreRol = scanner.nextLine();

        System.out.print("Descripción: ");
        String descripcion = scanner.nextLine();

        System.out.println("Permisos disponibles:");
        System.out.println("LECTURA, ESCRITURA, ELIMINACION, APROBACION, CONFIGURACION, GESTION_USUARIOS, INFORMES, etc.");
        System.out.print("Ingrese permisos separados por coma: ");
        String permisosInput = scanner.nextLine();

        Set<String> permisos = new HashSet<>();
        for (String permiso : permisosInput.split(",")) {
            permisos.add(permiso.trim().toUpperCase());
        }

        sistema.getFabricaRoles().crearRolPersonalizado(nombreRol, descripcion, permisos);
        System.out.println("Rol personalizado creado exitosamente");
    }

    private static void refrescarToken(SistemaLogin sistema, Logger logger) {
        if (!validarToken()) return;

        try {
            String nuevoToken = sistema.refrescarToken(tokenActual);
            tokenActual = nuevoToken;
            System.out.println("Token refrescado exitosamente");
            logger.log(Logger.Nivel.INFO, usuarioActual.getNombreUsuario(), "Token refrescado manualmente");
        } catch (Exception e) {
            System.out.println("Error refrescando token: " + e.getMessage());
            logger.log(Logger.Nivel.ERROR, usuarioActual.getNombreUsuario(), "Error refrescando token: " + e.getMessage());
        }
    }

    private static void mostrarInformacionToken() {
        if (!validarToken()) return;

        TokenManager tokenManager = TokenManager.getInstancia();
        try {
            System.out.println("\n INFORMACIÓN DEL TOKEN JWT");
            System.out.println("Usuario: " + tokenManager.obtenerUsernameDeToken(tokenActual));
            System.out.println("Rol: " + tokenManager.obtenerRolDeToken(tokenActual));
            System.out.println("ID Usuario: " + tokenManager.obtenerUserIdDeToken(tokenActual));
            System.out.println("Expira: " + tokenManager.obtenerExpiracionDeToken(tokenActual));
            System.out.println("Estado: " + (tokenManager.estaPorExpirar(tokenActual) ? "⚠️  Por expirar" : "✅ Válido"));
        } catch (Exception e) {
            System.out.println("Error leyendo token: " + e.getMessage());
        }
    }

    private static void cerrarSesion(SistemaLogin sistema, Logger logger) {
        if (tokenActual != null) {
            sistema.cerrarSesion(tokenActual);
            logger.log(Logger.Nivel.INFO, usuarioActual.getNombreUsuario(), "Cierre de sesión desde consola");
        }
        usuarioActual = null;
        tokenActual = null;
        System.out.println("Sesión cerrada exitosamente");
    }

    private static boolean validarToken() {
        SistemaLogin sistema = SistemaLogin.getInstancia();
        if (!sistema.validarToken(tokenActual)) {
            System.out.println("Token inválido o expirado. Por favor, inicie sesión nuevamente.");
            usuarioActual = null;
            tokenActual = null;
            return false;
        }
        return true;
    }

    private static void simularAccionesConLogging(Usuario usuario, Scanner scanner, Logger logger) {
        System.out.println("\nSIMULANDO ACCIONES...");

        // Simular acciones según permisos con logging
        if (usuario.tienePermiso("LECTURA")) {
            System.out.println("Consultando datos del sistema...");
            logger.logAccionSistema(usuario.getNombreUsuario(), "CONSULTA", "Base de datos principal");
        }

        if (usuario.tienePermiso("ESCRITURA")) {
            System.out.println("Modificando registros...");
            logger.logAccionSistema(usuario.getNombreUsuario(), "MODIFICACION", "Registros de usuario");
        }

        if (usuario.tienePermiso("APROBACION")) {
            System.out.println("Aprobando solicitudes pendientes...");
            logger.logAccionSistema(usuario.getNombreUsuario(), "APROBACION", "Solicitudes de gastos");
        }

        if (usuario.tienePermiso("GESTION_USUARIOS")) {
            System.out.println("Administrando usuarios del sistema...");
            logger.logAccionSistema(usuario.getNombreUsuario(), "ADMINISTRACION", "Gestión de usuarios");
        }

        if (usuario.tienePermiso("INFORMES")) {
            System.out.println("Generando informes...");
            logger.logAccionSistema(usuario.getNombreUsuario(), "GENERACION_INFORME", "Reportes del sistema");
        }

        logger.log(Logger.Nivel.INFO, usuario.getNombreUsuario(), "Simulación de acciones completada");
        System.out.println("Simulación completada para: " + usuario.getNombreUsuario());
    }
}