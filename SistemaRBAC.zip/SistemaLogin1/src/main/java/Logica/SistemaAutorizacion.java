package Logica;

import java.util.*;

public class SistemaAutorizacion{
    private Logger logger;

    public SistemaAutorizacion(){
        this.logger = Logger.getInstancia();
    }

    public void mostrarAutorizacion(Usuario usuario){
        System.out.println("\n" + "=".repeat(60));
        System.out.println("SISTEMA DE AUTORIZACIÓN - ACCESO CONCEDIDO");
        System.out.println("=".repeat(60));
        System.out.println("Usuario: " + usuario.getNombreUsuario());
        System.out.println("Rol: " + usuario.getRol().getNombre());
        System.out.println("Descripción: " + usuario.getRol().getDescripcion());
        
        mostrarPermisosPorCategoria(usuario);
        mostrarFuncionalidadesDisponibles(usuario);
        
        System.out.println("=".repeat(60));
        
        logger.log(Logger.Nivel.INFO, usuario.getNombreUsuario(), 
            "Autorización concedida para rol: " + usuario.getRol().getNombre());
    }

    private void mostrarPermisosPorCategoria(Usuario usuario){
        Map<String, List<Permiso>> permisosPorCategoria = new HashMap<>();
        
        for (Permiso permiso : usuario.getRol().getPermisos()){
            permisosPorCategoria.computeIfAbsent(permiso.getCategoria(), k -> new ArrayList<>())
                .add(permiso);
        }
        
        System.out.println("\nPERMISOS ASIGNADOS:");
        for (Map.Entry<String, List<Permiso>> entry : permisosPorCategoria.entrySet()) {
            System.out.println(entry.getKey() + ":");
            for (Permiso permiso : entry.getValue()) {
                System.out.println(permiso.getDescripcion());
            }
        }
    }

    private void mostrarFuncionalidadesDisponibles(Usuario usuario){
        System.out.println("\nFUNCIONALIDADES DISPONIBLES:");

        if (usuario.tienePermiso("LECTURA")) {
            System.out.println("• Consulta de información del sistema");
        }
        if (usuario.tienePermiso("EDICION")) {
            System.out.println("• Edición y modificación de datos");
        }
        if (usuario.tienePermiso("APROBACION")) {
            System.out.println("• Aprobación de solicitudes y documentos");
        }
        if (usuario.tienePermiso("DECISION")) {
            System.out.println("• Toma de decisiones estratégicas");
        }
        if (usuario.tienePermiso("CONTROL")) {
            System.out.println("• Supervisión y control de actividades");
        }
        if (usuario.tienePermiso("GESTION_TOTAL")) {
            System.out.println("• Gestión completa del sistema");
            System.out.println("• Administración de usuarios y roles");
            System.out.println("• Configuración del sistema");
            System.out.println("• Acceso a todas las funcionalidades");
        }
    }

    public boolean verificarPermiso(Usuario usuario, String codigoPermiso) {
        boolean tienePermiso = usuario.tienePermiso(codigoPermiso);
        
        if (!tienePermiso) {
            logger.log(Logger.Nivel.ADVERTENCIA, usuario.getNombreUsuario(), 
                "Intento de acceso sin permiso: " + codigoPermiso);
        }
        
        return tienePermiso;
    }
}