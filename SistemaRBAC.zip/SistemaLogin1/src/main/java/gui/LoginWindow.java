package gui;

import Logica.SistemaLogin;
import Logica.Logger;
import Logica.PasswordManager;
import com.formdev.flatlaf.FlatLightLaf;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginWindow extends JFrame {
    private JTextField txtUsuario;
    private JPasswordField txtClave;
    private JButton btnLogin, btnRegistrar;
    private JLabel lblMensaje;
    private SistemaLogin sistemaLogin;
    private Logger logger;

    public LoginWindow() {
        sistemaLogin = SistemaLogin.getInstancia();
        logger = Logger.getInstancia();
        initComponents();
    }

    private void initComponents() {
        setTitle("Sistema de Login - Autenticación");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(450, 400); // Aumentado el tamaño para el nuevo botón
        setLocationRelativeTo(null);
        setResizable(false);

        // Panel principal
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Título
        JLabel lblTitulo = new JLabel("SISTEMA DE LOGIN", JLabel.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 18));
        lblTitulo.setForeground(new Color(0));
        panel.add(lblTitulo, BorderLayout.NORTH);

        // Panel de formulario
        JPanel panelForm = new JPanel(new GridLayout(4, 2, 10, 10)); // Aumentado a 4 filas

        panelForm.add(new JLabel("Usuario:"));
        txtUsuario = new JTextField();
        panelForm.add(txtUsuario);

        panelForm.add(new JLabel("Contraseña:"));
        txtClave = new JPasswordField();
        panelForm.add(txtClave);

        // Panel de botones
        JPanel panelBotones = new JPanel(new GridLayout(1, 2, 10, 10));

        btnLogin = new JButton("Iniciar Sesión");

        btnLogin.setFocusPainted(false);
        btnRegistrar = new JButton("Registrarse");

        btnRegistrar.setFocusPainted(false);

        panelBotones.add(btnLogin);
        panelBotones.add(btnRegistrar);

        lblMensaje = new JLabel(" ", JLabel.CENTER);
        lblMensaje.setForeground(Color.RED);

        panelForm.add(panelBotones);
        panelForm.add(lblMensaje);

        panel.add(panelForm, BorderLayout.CENTER);

        // Panel inferior con información
        JPanel panelInferior = new JPanel();
        panelInferior.setBorder(BorderFactory.createMatteBorder(1,1,1,1,Color.GRAY));
        JTextArea txtInfo = new JTextArea(
                "Si es la primera vez que usa el sistema,\n" +
                        "haga clic en 'Registrarse' para crear\n" +
                        "una cuenta de administrador.\n\n" +
                        "Roles disponibles:\n" +
                        "- Administrador\n" +
                        "- Supervisor\n" +
                        "- Director\n" +
                        "- Gerente\n" +
                        "- Jefe de Área\n" +
                        "- Personal"
        );
        txtInfo.setEditable(false);
        txtInfo.setBackground(panel.getBackground());
        txtInfo.setFont(new Font("Arial", Font.PLAIN, 11));
        panelInferior.add(txtInfo);
        panel.add(panelInferior, BorderLayout.SOUTH);

        add(panel);
        // Accion del boton de login
        btnLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                realizarLogin();
            }
        });
        // Accion del botón de registro
        btnRegistrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarDialogoRegistro();
            }
        });
    }

    private void realizarLogin() {
        String usuario = txtUsuario.getText().trim();
        String clave = new String(txtClave.getPassword());

        if (usuario.isEmpty() || clave.isEmpty()) {
            lblMensaje.setText("Usuario y contraseña son requeridos");
            return;
        }

        btnLogin.setText("Autenticando...");
        btnLogin.setEnabled(false);
        btnRegistrar.setEnabled(false);

        new Thread(() -> {
            try {
                SistemaLogin.AuthResult resultado = sistemaLogin.autenticar(usuario, clave);
                SwingUtilities.invokeLater(() -> {
                    if (resultado.isExitoso()) {
                        // Login exitoso
                        logger.log(Logger.Nivel.INFO, usuario, "Login exitoso");
                        // Abrir dashboard principal
                        MainDashboard dashboard = new MainDashboard(resultado.getUsuario(), resultado.getToken());
                        dashboard.setVisible(true);
                        // Cerrar ventana de login
                        dispose();
                    } else {
                        // Login fallido
                        lblMensaje.setText(resultado.getMensaje());
                        btnLogin.setText("Iniciar Sesión");
                        btnLogin.setEnabled(true);
                        btnRegistrar.setEnabled(true);
                        logger.log(Logger.Nivel.SEGURIDAD, usuario, "Intento fallido de Login");
                    }
                });

            } catch (Exception ex) {
                SwingUtilities.invokeLater(() -> {
                    lblMensaje.setText("Error: " + ex.getMessage());
                    btnLogin.setText("Iniciar Sesión");
                    btnLogin.setEnabled(true);
                    btnRegistrar.setEnabled(true);
                });
            }
        }).start();
    }

    // Dialogo de registro
    private void mostrarDialogoRegistro() {
        JDialog dialog = new JDialog(this, "Registro de Nuevo Usuario", true);
        dialog.setSize(400, 350);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout(10, 10));
        dialog.setResizable(false);
        // Panel principal
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        // Título
        JLabel lblTitulo = new JLabel("REGISTRO DE NUEVO USUARIO", JLabel.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 16));
        lblTitulo.setForeground(new Color(0));
        panel.add(lblTitulo, BorderLayout.NORTH);
        // Panel de formulario
        JPanel panelForm = new JPanel(new GridLayout(5, 2, 10, 10));
        JTextField txtNuevoUsuario = new JTextField();
        JPasswordField txtNuevaClave = new JPasswordField();
        JPasswordField txtConfirmarClave = new JPasswordField();
        JComboBox<String> cmbRol = new JComboBox<>(new String[]{
                "Personal", "Jefe de Área", "Gerente", "Director", "Supervisor", "Administrador del Sistema"
        });
        panelForm.add(new JLabel("Usuario:"));
        panelForm.add(txtNuevoUsuario);
        panelForm.add(new JLabel("Contraseña:"));
        panelForm.add(txtNuevaClave);
        panelForm.add(new JLabel("Confirmar Contraseña:"));
        panelForm.add(txtConfirmarClave);
        panelForm.add(new JLabel("Rol:"));
        panelForm.add(cmbRol);
        // Etiqueta para mensajes
        JLabel lblMensajeRegistro = new JLabel(" ", JLabel.CENTER);
        lblMensajeRegistro.setForeground(Color.RED);
        panelForm.add(lblMensajeRegistro);
        // Panel de botones
        JPanel panelBotones = new JPanel(new FlowLayout());
        JButton btnConfirmar = new JButton("Confirmar Registro");
        btnConfirmar.setBackground(new Color(0, 150, 0));
        btnConfirmar.setForeground(Color.WHITE);

        JButton btnCancelar = new JButton("Cancelar");
        btnCancelar.setBackground(new Color(200, 0, 0));
        btnCancelar.setForeground(Color.WHITE);

        panelBotones.add(btnConfirmar);
        panelBotones.add(btnCancelar);

        panelForm.add(panelBotones);

        panel.add(panelForm, BorderLayout.CENTER);

        // Panel de requisitos de contraseña
        JPanel panelRequisitos = new JPanel();
        panelRequisitos.setBorder(BorderFactory.createTitledBorder("Requisitos de Contraseña"));
        JTextArea txtRequisitos = new JTextArea(
                "• Mínimo 8 caracteres\n" +
                        "• Al menos una mayúscula\n" +
                        "• Al menos una minúscula\n" +
                        "• Al menos un número\n" +
                        "• Al menos un símbolo"
        );
        txtRequisitos.setEditable(false);
        txtRequisitos.setBackground(panel.getBackground());
        txtRequisitos.setFont(new Font("Arial", Font.PLAIN, 10));
        panelRequisitos.add(txtRequisitos);
        panel.add(panelRequisitos, BorderLayout.SOUTH);

        dialog.add(panel);

        // Acción del botón confirmar
        btnConfirmar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String usuario = txtNuevoUsuario.getText().trim();
                String clave = new String(txtNuevaClave.getPassword());
                String confirmarClave = new String(txtConfirmarClave.getPassword());
                String rol = (String) cmbRol.getSelectedItem();
                // Validaciones
                if(usuario.isEmpty() || clave.isEmpty()){
                    lblMensajeRegistro.setText("Usuario y contraseña son requeridos");
                    return;
                }
                if(!clave.equals(confirmarClave)){
                    lblMensajeRegistro.setText("Las contraseñas no coinciden");
                    return;
                }
                // Verificar fortaleza de la contraseña
                if(!PasswordManager.getInstancia().esPasswordFuerte(clave)){
                    lblMensajeRegistro.setText("La contraseña no cumple los requisitos");
                    return;
                }
                // Verificar si el usuario ya existe
                if(sistemaLogin.existeUsuario(usuario)){
                    lblMensajeRegistro.setText("El usuario ya existe");
                    return;
                }
                // registro
                try{
                    sistemaLogin.crearUsuarioConRol(usuario, clave, rol);
                    lblMensajeRegistro.setText("Usuario registrado exitosamente");
                    logger.log(Logger.Nivel.INFO, "Sistema", "Nuevo usuario registrado: " + usuario + " con rol: " + rol);

                    // Cerrar diálogo después de 2 segundos
                    new Timer(2000, new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent evt) {
                            dialog.dispose();
                        }
                    }).start();

                }catch (Exception ex) {
                    lblMensajeRegistro.setText("Error: " + ex.getMessage());
                    logger.log(Logger.Nivel.ERROR, "Sistema", "Error en registro: " + ex.getMessage());
                }
            }
        });

        // Acción del botón cancelar
        btnCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dialog.dispose();
            }
        });

        dialog.setVisible(true);
    }

    public static void main(String[] args) {
        // Usar FlatLaf (más moderno)
        try {
            UIManager.setLookAndFeel(new FlatLightLaf());
        } catch (Exception e) {
            e.printStackTrace();
        }

        SwingUtilities.invokeLater(() -> new LoginWindow().setVisible(true));
    }
}