package gui;

import Logica.SistemaLogin;
import Logica.Logger;
import Logica.SistemaAutorizacion;
import Logica.Usuario;
import Logica.Permiso;
import Logica.TokenManager;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import java.util.List;
import java.util.Timer;

public class MainDashboard extends JFrame {
    private Usuario usuario;
    private String token;
    private SistemaLogin sistemaLogin;
    private Logger logger;
    private SistemaAutorizacion sistemaAutorizacion;
    private TokenManager tokenManager;
    private Timer timerRefresco;

    // CONSTRUCTOR
    public MainDashboard(Usuario usuario, String token) {
        this.usuario = usuario;
        this.token = token;
        this.sistemaLogin = SistemaLogin.getInstancia();
        this.logger = Logger.getInstancia();
        this.sistemaAutorizacion = new SistemaAutorizacion();
        this.tokenManager = TokenManager.getInstancia();

        initComponents();
        iniciarRefrescoAutomatico();
        logger.log(Logger.Nivel.INFO, usuario.getNombreUsuario(), "Acceso al dashboard");
    }

    // Refrescar token automáticamente
    private void iniciarRefrescoAutomatico() {
        timerRefresco = new Timer();
        timerRefresco.schedule(new TimerTask() {
            @Override
            public void run() {
                verificarYRefrescarToken();
            }
        }, 0, 60000);
    }

    // Verificar y refrescar token si es necesario
    private void verificarYRefrescarToken() {
        if (tokenManager.estaPorExpirar(token)) {
            try {
                String nuevoToken = sistemaLogin.refrescarToken(token);
                this.token = nuevoToken;
                logger.log(Logger.Nivel.INFO, usuario.getNombreUsuario(), "Token refrescado automáticamente");
            } catch (Exception ex) {
                logger.log(Logger.Nivel.ERROR, usuario.getNombreUsuario(),
                        "Error refrescando token: " + ex.getMessage());
            }
        }
    }

    // Validar acceso con token
    private boolean validarAcceso() {
        if (!sistemaLogin.validarToken(token)) {
            JOptionPane.showMessageDialog(this,
                    "Su sesión ha expirado. Por favor, inicie sesión nuevamente.",
                    "Sesión Expirada", JOptionPane.WARNING_MESSAGE);
            cerrarSesion();
            return false;
        }
        return true;
    }

    private void initComponents() {
        setTitle("Sistema de Login - Dashboard (Token: " + token.substring(0, 10) + "...)"); // MOSTRAR TOKEN EN TÍTULO
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);
        // Crear pestañas
        JTabbedPane tabbedPane = new JTabbedPane();
        // Pestaña 1: Información del Usuario
        tabbedPane.addTab("Información", crearPanelInformacion());
        // Pestaña 2: Funcionalidades
        tabbedPane.addTab("Funcionalidades", crearPanelFuncionalidades());
        // Pestaña 3: Logs (solo para administradores)
        if (usuario.tienePermiso("CONTROL") || usuario.tienePermiso("GESTION_TOTAL")) {
            tabbedPane.addTab("Logs del Sistema", crearPanelLogs());
        }
        // Pestaña 4: Gestión de Usuarios (solo para administradores)
        if (usuario.tienePermiso("GESTION_TOTAL")) {
            tabbedPane.addTab("Gestión de Usuarios", crearPanelGestionUsuarios());
        }
        // Información del Token
        tabbedPane.addTab("Token Info", crearPanelTokenInfo());
        add(tabbedPane);
        // Barra de estado
        JPanel panelEstado = new JPanel(new BorderLayout());
        JLabel lblEstado = new JLabel("Usuario: " + usuario.getNombreUsuario() +
                " | Token expira: " + tokenManager.obtenerExpiracionDeToken(token));
        panelEstado.add(lblEstado, BorderLayout.WEST);
        JButton btnCerrarSesion = new JButton("Cerrar Sesión");
        btnCerrarSesion.addActionListener(e -> cerrarSesion());
        panelEstado.add(btnCerrarSesion, BorderLayout.EAST);
        add(panelEstado, BorderLayout.SOUTH);
    }

    // Panel de información del token
    private JPanel crearPanelTokenInfo() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel panelInfo = new JPanel(new GridLayout(0, 1, 5, 5));
        panelInfo.setBorder(BorderFactory.createTitledBorder("Información del Token JWT"));

        try {
            panelInfo.add(new JTextArea("Token: " + token));
            panelInfo.add(new JLabel("Usuario: " + tokenManager.obtenerUsernameDeToken(token)));
            panelInfo.add(new JLabel("Rol: " + tokenManager.obtenerRolDeToken(token)));
            panelInfo.add(new JLabel("ID Usuario: " + tokenManager.obtenerUserIdDeToken(token)));
            panelInfo.add(new JLabel("Expira: " + tokenManager.obtenerExpiracionDeToken(token)));
            panelInfo.add(new JLabel("Estado: " + (tokenManager.estaPorExpirar(token) ? "Por expirar" : "Válido")));

            JButton btnRefrescar = new JButton("Refrescar Token Manualmente");
            btnRefrescar.addActionListener(e -> {
                try {
                    String nuevoToken = sistemaLogin.refrescarToken(token);
                    this.token = nuevoToken;
                    JOptionPane.showMessageDialog(this, "Token refrescado exitosamente");
                    // Actualizar la ventana
                    dispose();
                    new MainDashboard(usuario, nuevoToken).setVisible(true);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "Error refrescando token: " + ex.getMessage());
                }
            });
            panelInfo.add(btnRefrescar);
        } catch (Exception e) {
            panelInfo.add(new JLabel("Error leyendo token: " + e.getMessage()));
        }
        panel.add(panelInfo, BorderLayout.NORTH);
        return panel;
    }

    private JPanel crearPanelInformacion() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        // Información del usuario
        JPanel panelInfo = new JPanel(new GridLayout(0, 1, 5, 5));
        panelInfo.setBorder(BorderFactory.createTitledBorder("Información del Usuario"));

        panelInfo.add(new JLabel("Nombre de usuario: " + usuario.getNombreUsuario()));
        panelInfo.add(new JLabel("Rol: " + usuario.getRol().getNombre()));
        panelInfo.add(new JLabel("Descripción: " + usuario.getRol().getDescripcion()));

        JLabel lblPermisos = new JLabel("Permisos:");
        panelInfo.add(lblPermisos);

        // Lista de permisos
        DefaultListModel<String> modeloPermisos = new DefaultListModel<>();
        for (Permiso permiso : usuario.getRol().getPermisos()) {
            modeloPermisos.addElement("• " + permiso.getCodigo() + " - " + permiso.getDescripcion());
        }
        JList<String> listaPermisos = new JList<>(modeloPermisos);
        JScrollPane scrollPermisos = new JScrollPane(listaPermisos);

        panel.add(panelInfo, BorderLayout.NORTH);
        panel.add(scrollPermisos, BorderLayout.CENTER);

        return panel;
    }

    private JPanel crearPanelFuncionalidades() {
        JPanel panel = new JPanel(new GridLayout(0, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Botones según permisos
        if (usuario.tienePermiso("LECTURA")) {
            JButton btnConsulta = new JButton("Consultar Información");
            btnConsulta.addActionListener(e -> {
                if (!validarAcceso()) return;
                JOptionPane.showMessageDialog(this, "Ejecutando consulta de información...");
                logger.logAccionSistema(usuario.getNombreUsuario(), "CONSULTA", "Información del sistema");
            });
            panel.add(btnConsulta);
        }
        if (usuario.tienePermiso("ESCRITURA")) {
            JButton btnEdicion = new JButton(" Editar Registros");
            btnEdicion.addActionListener(e -> {
                if (!validarAcceso()) return;
                JOptionPane.showMessageDialog(this, "Editando registros...");
                logger.logAccionSistema(usuario.getNombreUsuario(), "EDICION", "Registros del sistema");
            });
            panel.add(btnEdicion);
        }
        if (usuario.tienePermiso("APROBACION")) {
            JButton btnAprobacion = new JButton("Aprobar Solicitudes");
            btnAprobacion.addActionListener(e -> {
                if (!validarAcceso()) return;
                JOptionPane.showMessageDialog(this, "Procesando aprobaciones...");
                logger.logAccionSistema(usuario.getNombreUsuario(), "APROBACION", "Solicitudes pendientes");
            });
            panel.add(btnAprobacion);
        }
        if (usuario.tienePermiso("INFORMES")) {
            JButton btnInformes = new JButton("Generar Informes");
            btnInformes.addActionListener(e -> {
                if (!validarAcceso()) return;
                JOptionPane.showMessageDialog(this, "Generando informe...");
                logger.logAccionSistema(usuario.getNombreUsuario(), "GENERACION_INFORME", "Reportes del sistema");
            });
            panel.add(btnInformes);
        }

        if (panel.getComponentCount() == 0) {
            panel.add(new JLabel("No hay funcionalidades disponibles para su rol"));
        }

        return panel;
    }

    private JPanel crearPanelLogs() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JButton btnActualizar = new JButton("Actualizar Logs");
        JTextArea txtLogs = new JTextArea();
        txtLogs.setEditable(false);
        JScrollPane scrollLogs = new JScrollPane(txtLogs);

        btnActualizar.addActionListener(e -> {
            if (!validarAcceso()) return; // validar token
            List<String> logs = logger.obtenerUltimosLogsComoLista(50);
            StringBuilder sb = new StringBuilder();
            for (String log : logs) {
                sb.append(log).append("\n");
            }
            txtLogs.setText(sb.toString());
        });

        // Cargar logs inicialmente
        btnActualizar.doClick();
        panel.add(btnActualizar, BorderLayout.NORTH);
        panel.add(scrollLogs, BorderLayout.CENTER);

        return panel;
    }

    private JPanel crearPanelGestionUsuarios() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel panelBotones = new JPanel(new FlowLayout());

        JButton btnVerUsuarios = new JButton("Ver Usuarios");
        JButton btnCrearUsuario = new JButton("Crear Usuario");
        JButton btnGestionRoles = new JButton("Gestionar Roles");

        btnVerUsuarios.addActionListener(e -> {
            if (!validarAcceso()) return; // validar token
            mostrarUsuarios();
        });
        btnCrearUsuario.addActionListener(e -> {
            if (!validarAcceso()) return; // validar token
            crearUsuario();
        });
//        btnGestionRoles.addActionListener(e -> {
//            if (!validarAcceso()) return; // validar token
//
//        });

        panelBotones.add(btnVerUsuarios);
        panelBotones.add(btnCrearUsuario);
        panelBotones.add(btnGestionRoles);

        panel.add(panelBotones, BorderLayout.NORTH);

        return panel;
    }

    private void mostrarUsuarios() {
        if (!validarAcceso()) return; // validar token
        // Obtener todos los usuarios del sistema
        Map<String, Usuario> usuarios = sistemaLogin.obtenerTodosUsuarios();
        if (usuarios.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "No hay usuarios registrados en el sistema.",
                    "Lista de Usuarios",
                    JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        // Crear diálogo para mostrar usuarios
        JDialog dialog = new JDialog(this, "Lista de Usuarios Registrados", true);
        dialog.setSize(600, 400);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout(10, 10));

        // Panel principal
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Titulo
        JLabel lblTitulo = new JLabel("USUARIOS REGISTRADOS EN EL SISTEMA", JLabel.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 14));
        lblTitulo.setForeground(new Color(0, 100, 200));
        panel.add(lblTitulo, BorderLayout.NORTH);

        // Modelo de tabla para mostrar usuarios
        String[] columnNames = {"Usuario", "Rol", "Descripción del Rol", "N° de Permisos"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Hacer la tabla no editable
            }
        };
        // Llenar la tabla con datos de usuarios
        for (Usuario usuario : usuarios.values()) {
            String nombreUsuario = usuario.getNombreUsuario();
            String rolNombre = usuario.getRol() != null ? usuario.getRol().getNombre() : "Sin rol";
            String rolDescripcion = usuario.getRol() != null ? usuario.getRol().getDescripcion() : "Sin descripción";
            int numPermisos = usuario.getRol() != null ? usuario.getRol().getPermisos().size() : 0;

            model.addRow(new Object[]{nombreUsuario, rolNombre, rolDescripcion, numPermisos});
        }
        JTable tablaUsuarios = new JTable(model);
        tablaUsuarios.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tablaUsuarios.getTableHeader().setReorderingAllowed(false);

        // Mejorar la apariencia de la tabla
        tablaUsuarios.setRowHeight(25);
        tablaUsuarios.getColumnModel().getColumn(0).setPreferredWidth(120);
        tablaUsuarios.getColumnModel().getColumn(1).setPreferredWidth(100);
        tablaUsuarios.getColumnModel().getColumn(2).setPreferredWidth(200);
        tablaUsuarios.getColumnModel().getColumn(3).setPreferredWidth(80);

        JScrollPane scrollPane = new JScrollPane(tablaUsuarios);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Lista de Usuarios (" + usuarios.size() + " usuarios)"));

        panel.add(scrollPane, BorderLayout.CENTER);

        // Panel inferior con botones e información adicional
        JPanel panelInferior = new JPanel(new BorderLayout());

        // Información del usuario seleccionado
        JTextArea txtInfoUsuario = new JTextArea(3, 40);
        txtInfoUsuario.setEditable(false);
        txtInfoUsuario.setBorder(BorderFactory.createTitledBorder("Información del Usuario Seleccionado"));
        txtInfoUsuario.setBackground(panel.getBackground());

        // Listener para mostrar información del usuario seleccionado
        tablaUsuarios.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int selectedRow = tablaUsuarios.getSelectedRow();
                if (selectedRow != -1) {
                    String usuarioSeleccionado = (String) model.getValueAt(selectedRow, 0);
                    Usuario usuario = usuarios.get(usuarioSeleccionado);

                    if (usuario != null && usuario.getRol() != null) {
                        StringBuilder info = new StringBuilder();
                        info.append("Usuario: ").append(usuario.getNombreUsuario()).append("\n");
                        info.append("Rol: ").append(usuario.getRol().getNombre()).append("\n");
                        info.append("Permisos: ").append(usuario.getRol().getPermisos().size());

                        txtInfoUsuario.setText(info.toString());
                    }
                }
            }
        });
        panelInferior.add(txtInfoUsuario, BorderLayout.CENTER);
        // Botones de acción
        JPanel panelBotones = new JPanel(new FlowLayout());

        JButton btnVerPermisos = new JButton("Ver Permisos Detallados");
        JButton btnCerrar = new JButton("Cerrar");

        btnVerPermisos.addActionListener(e -> {
            int selectedRow = tablaUsuarios.getSelectedRow();
            if (selectedRow != -1) {
                String usuarioSeleccionado = (String) model.getValueAt(selectedRow, 0);
                Usuario usuario = usuarios.get(usuarioSeleccionado);

                if (usuario != null && usuario.getRol() != null) {
                    mostrarPermisosUsuario(usuario);
                }
            } else {
                JOptionPane.showMessageDialog(dialog,
                        "seleccione un usuario para ver sus permisos.",
                        "Selección Requerida",
                        JOptionPane.WARNING_MESSAGE);
            }
        });

        btnCerrar.addActionListener(e -> dialog.dispose());

        panelBotones.add(btnVerPermisos);
        panelBotones.add(btnCerrar);

        panelInferior.add(panelBotones, BorderLayout.SOUTH);
        panel.add(panelInferior, BorderLayout.SOUTH);

        dialog.add(panel);
        dialog.setVisible(true);

        // Log de la acción
        logger.log(Logger.Nivel.INFO, usuario.getNombreUsuario(),
                "Consultó la lista de usuarios - Total: " + usuarios.size() + " usuarios");
    }

    // Metodo para mostrar permisos de un usuario
    private void mostrarPermisosUsuario(Usuario usuario) {
        if (usuario.getRol() == null || usuario.getRol().getPermisos().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "El usuario '" + usuario.getNombreUsuario() + "' no tiene permisos asignados.",
                    "Permisos del Usuario",
                    JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        JDialog dialogPermisos = new JDialog(this, "Permisos de " + usuario.getNombreUsuario(), true);
        dialogPermisos.setSize(500, 300);
        dialogPermisos.setLocationRelativeTo(this);

        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Título
        JLabel lblTitulo = new JLabel("PERMISOS ASIGNADOS A: " + usuario.getNombreUsuario(), JLabel.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 14));
        panel.add(lblTitulo, BorderLayout.NORTH);

        // Lista de permisos
        DefaultListModel<String> modeloPermisos = new DefaultListModel<>();

        // Agrupar permisos por categoría
        Map<String, List<Permiso>> permisosPorCategoria = new HashMap<>();
        for (Permiso permiso : usuario.getRol().getPermisos()) {
            permisosPorCategoria
                    .computeIfAbsent(permiso.getCategoria(), k -> new ArrayList<>())
                    .add(permiso);
        }

        for (Map.Entry<String, List<Permiso>> entry : permisosPorCategoria.entrySet()) {
            modeloPermisos.addElement("=== " + entry.getKey() + " ===");
            for (Permiso permiso : entry.getValue()) {
                modeloPermisos.addElement("  • " + permiso.getCodigo() + " - " + permiso.getDescripcion());
            }
            modeloPermisos.addElement(""); // Línea en blanco
        }

        JList<String> listaPermisos = new JList<>(modeloPermisos);
        listaPermisos.setFont(new Font("Monospaced", Font.PLAIN, 12));

        JScrollPane scrollPermisos = new JScrollPane(listaPermisos);
        scrollPermisos.setBorder(BorderFactory.createTitledBorder(
                "Total de permisos: " + usuario.getRol().getPermisos().size()));

        panel.add(scrollPermisos, BorderLayout.CENTER);

        // Botón cerrar
        JButton btnCerrar = new JButton("Cerrar");
        btnCerrar.addActionListener(e -> dialogPermisos.dispose());

        JPanel panelBoton = new JPanel();
        panelBoton.add(btnCerrar);
        panel.add(panelBoton, BorderLayout.SOUTH);

        dialogPermisos.add(panel);
        dialogPermisos.setVisible(true);
    }


    private void crearUsuario() {
        if (!validarAcceso()) return; // validar token
        // Verificar permisos usando el token
        String rolDesdeToken = tokenManager.obtenerRolDeToken(token);
        if (!usuario.tienePermiso("GESTION_TOTAL")) {
            JOptionPane.showMessageDialog(this,
                    "No tiene permisos para crear usuarios.",
                    "Acceso Denegado", JOptionPane.ERROR_MESSAGE);
            return;
        }
        JTextField txtUsuario = new JTextField();
        JPasswordField txtClave = new JPasswordField();
        JComboBox<String> cmbRoles = new JComboBox<>(new String[]{
                "Personal", "Jefe de Área", "Gerente", "Director", "Supervisor", "Administrador del Sistema"
        });
        JPanel panel = new JPanel(new GridLayout(0, 1, 5, 5));
        panel.add(new JLabel("Usuario:"));
        panel.add(txtUsuario);
        panel.add(new JLabel("Contraseña:"));
        panel.add(txtClave);
        panel.add(new JLabel("Rol:"));
        panel.add(cmbRoles);
        int result = JOptionPane.showConfirmDialog(this, panel,
                "Crear Nuevo Usuario", JOptionPane.OK_CANCEL_OPTION);

        if (result == JOptionPane.OK_OPTION) {
            String usuario = txtUsuario.getText();
            String clave = new String(txtClave.getPassword());
            String rol = (String) cmbRoles.getSelectedItem();

            sistemaLogin.crearUsuarioConRol(usuario, clave, rol);
            JOptionPane.showMessageDialog(this, "Usuario creado exitosamente");
        }
    }

    private void gestionarRoles() {
        if (!validarAcceso()) return; // validar token
        JOptionPane.showMessageDialog(this,
                "...");
    }

    private void cerrarSesion() {
        // Detener el timer de refresco
        if (timerRefresco != null) {
            timerRefresco.cancel();
        }

        //Invalidar el token en el sistema
        sistemaLogin.cerrarSesion(token);

        logger.log(Logger.Nivel.INFO, usuario.getNombreUsuario(), "Cierre de sesión desde GUI");
        int confirm = JOptionPane.showConfirmDialog(this,
                "¿Está seguro que desea cerrar sesión?",
                "Confirmar cierre de sesión",
                JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            // Volver a la ventana de login
            LoginWindow loginWindow = new LoginWindow();
            loginWindow.setVisible(true);
            dispose();
        }
    }
}