package Persistencia;

import Logica.Usuario;
import Logica.Rol;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;


public class UsuarioDAO {
    private DatabaseConnection dbConnection;
    private RolDAO rolDAO;

    public UsuarioDAO(){
        this.dbConnection = DatabaseConnection.getInstancia();
        this.rolDAO = new RolDAO();
    }

    public void guardarUsuario(Usuario usuario){
        String sql = "INSERT OR REPLACE INTO usuarios (nombre_usuario, clave, rol_id) VALUES (?, ?, ?)";
        
        try (Connection conn = dbConnection.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setString(1, usuario.getNombreUsuario());
            pstmt.setString(2, usuario.getClave());
            pstmt.setInt(3, usuario.getRol().getId());

            
            pstmt.executeUpdate();
            
            // Obtener el ID generado
            ResultSet generatedKeys = pstmt.getGeneratedKeys();
            if (generatedKeys.next()){
                usuario.setId(generatedKeys.getInt(1));
            }
            
        } catch (SQLException e){
            System.err.println("Error guardando usuario: " + e.getMessage());
        }
    }

    public Usuario obtenerUsuario(int id){
        String sql = "SELECT u.*, r.id as rol_id, r.nombre as rol_nombre, r.descripcion as rol_descripcion " +
                    "FROM usuarios u LEFT JOIN roles r ON u.rol_id = r.id WHERE u.id = ?";
        
        try (Connection conn = dbConnection.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)){
            
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return mapearUsuario(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error obteniendo usuario: " + e.getMessage());
        }
        return null;
    }

    public Usuario obtenerUsuarioPorNombre(String nombreUsuario){
        String sql = "SELECT u.*, r.id as rol_id, r.nombre as rol_nombre, r.descripcion as rol_descripcion " +
                    "FROM usuarios u LEFT JOIN roles r ON u.rol_id = r.id WHERE u.nombre_usuario = ?";
        
        try (Connection conn = dbConnection.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, nombreUsuario);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return mapearUsuario(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error obteniendo usuario por nombre: " + e.getMessage());
        }
        return null;
    }
    
    private Usuario mapearUsuario(ResultSet rs) throws SQLException{
        Usuario usuario = new Usuario();
        usuario.setId(rs.getInt("id"));
        usuario.setNombreUsuario(rs.getString("nombre_usuario"));
        usuario.setClaveHash(rs.getString("clave"));
        // Cargar rol si existe
        int rolId = rs.getInt("rol_id");
        if (!rs.wasNull()) {
            Rol rol = rolDAO.obtenerRol(rolId);
            usuario.setRol(rol);
        }
        return usuario;
    }
    
    public Map<String, Usuario> obtenerTodosUsuarios(){
        Map<String, Usuario> usuarios = new HashMap<>();
        String sql = "SELECT u.*, r.id as rol_id, r.nombre as rol_nombre, r.descripcion as rol_descripcion " +
                    "FROM usuarios u LEFT JOIN roles r ON u.rol_id = r.id";
        
        try (Connection conn = dbConnection.getConexion();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()){
                Usuario usuario = mapearUsuario(rs);
                usuarios.put(usuario.getNombreUsuario(), usuario);
            }
        } catch (SQLException e){
            System.err.println("Error obteniendo usuarios: " + e.getMessage());
        }
        return usuarios;
    }
    
    public boolean existeUsuario(String nombreUsuario){
        String sql = "SELECT 1 FROM usuarios WHERE nombre_usuario = ?";
        
        try (Connection conn = dbConnection.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)){
            
            pstmt.setString(1, nombreUsuario);
            ResultSet rs = pstmt.executeQuery();
            return rs.next();
            
        } catch (SQLException e){
            System.err.println("Error verificando existencia de usuario: " + e.getMessage());
        }
        return false;
    }
    
    public void eliminarUsuario(String nombreUsuario){
        String sql = "DELETE FROM usuarios WHERE nombre_usuario = ?";
        
        try (Connection conn = dbConnection.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)){
            
            pstmt.setString(1, nombreUsuario);
            pstmt.executeUpdate();
            
        } catch (SQLException e){
            System.err.println("Error eliminando usuario: " + e.getMessage());
        }
    }
}
