package Persistencia;

import Logica.Rol;
import Logica.Permiso;
import java.sql.*;
import java.util.HashSet;
import java.util.Set;

public class RolDAO{
    private DatabaseConnection dbConnection;
    private PermisoDAO permisoDAO;

    public RolDAO(){
        this.dbConnection = DatabaseConnection.getInstancia();
        this.permisoDAO = new PermisoDAO();
    }

    public void guardarRol(Rol rol){
        String sql = "INSERT OR REPLACE INTO roles (nombre, descripcion) VALUES (?, ?)";
        
        try (Connection conn = dbConnection.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setString(1, rol.getNombre());
            pstmt.setString(2, rol.getDescripcion());
            pstmt.executeUpdate();
            
            // Obtener el ID generado
            ResultSet generatedKeys = pstmt.getGeneratedKeys();
            if (generatedKeys.next()){
                rol.setId(generatedKeys.getInt(1));
            }
            
            // Guardar permisos del rol
            guardarPermisosRol(rol);
            
        } catch (SQLException e){
            System.err.println("Error guardando rol: " + e.getMessage());
        }
    }

    private void guardarPermisosRol(Rol rol){
        // Primero limpiar permisos existentes
        String deleteSql = "DELETE FROM rol_permiso WHERE rol_id = ?";
        try (Connection conn = dbConnection.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(deleteSql)) {
            
            pstmt.setInt(1, rol.getId());
            pstmt.executeUpdate();
            
        } catch (SQLException e){
            System.err.println("Error limpiando permisos del rol: " + e.getMessage());
            return;
        }

        // Luego insertar los nuevos permisos
        for (Permiso permiso : rol.getPermisos()){
            permisoDAO.asignarPermisoARol(rol.getId(), permiso.getCodigo());
        }
    }

    public Rol obtenerRol(int id){
        String sql = "SELECT * FROM roles WHERE id = ?";
        
        try (Connection conn = dbConnection.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()){
                Rol rol = new Rol(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("descripcion")
                );
                
                // Cargar permisos del rol
                Set<Permiso> permisos = permisoDAO.obtenerPermisosPorRol(id);
                rol.setPermisos(permisos);
                
                return rol;
            }
        } catch (SQLException e){
            System.err.println("Error obteniendo rol: " + e.getMessage());
        }
        return null;
    }

    public Rol obtenerRolPorNombre(String nombre){
        String sql = "SELECT * FROM roles WHERE nombre = ?";
        
        try (Connection conn = dbConnection.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, nombre);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()){
                Rol rol = new Rol(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("descripcion")
                );
                
                // Cargar permisos del rol
                Set<Permiso> permisos = permisoDAO.obtenerPermisosPorRol(rol.getId());
                rol.setPermisos(permisos);
                
                return rol;
            }
        } catch (SQLException e){
            System.err.println("Error obteniendo rol por nombre: " + e.getMessage());
        }
        return null;
    }

    public Set<Rol> obtenerTodosRoles(){
        Set<Rol> roles = new HashSet<>();
        String sql = "SELECT * FROM roles";
        
        try (Connection conn = dbConnection.getConexion();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()){
                Rol rol = new Rol(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("descripcion")
                );
                
                // Cargar permisos del rol
                Set<Permiso> permisos = permisoDAO.obtenerPermisosPorRol(rol.getId());
                rol.setPermisos(permisos);
                
                roles.add(rol);
            }
        } catch (SQLException e){
            System.err.println("Error obteniendo roles: " + e.getMessage());
        }
        return roles;
    }

    public boolean existeRol(String nombre){
        String sql = "SELECT 1 FROM roles WHERE nombre = ?";
        
        try (Connection conn = dbConnection.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, nombre);
            ResultSet rs = pstmt.executeQuery();
            return rs.next();
            
        } catch (SQLException e){
            System.err.println("Error verificando existencia de rol: " + e.getMessage());
        }
        return false;
    }
}
