package Persistencia;

import java.sql.*;

public class DatabaseConnection{
    private static final String URL = "jdbc:sqlite:sistema_login.db";
    private static DatabaseConnection instancia;
    private Connection conexion;

    private DatabaseConnection(){
        conectar();
        crearTablas();
    }

    public static DatabaseConnection getInstancia(){
        if (instancia == null){
            instancia = new DatabaseConnection();
        }
        return instancia;
    }

    private void conectar(){
        try {
            Class.forName("org.sqlite.JDBC");
            conexion = DriverManager.getConnection(URL);
            System.out.println("Conexión a SQLite establecida.");
        } catch (Exception e) {
            System.err.println("Error conectando a la base de datos: " + e.getMessage());
        }
    }

    private void crearTablas() {
        String[] tablas = {
            // Tabla de permisos
            "CREATE TABLE IF NOT EXISTS permisos (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
            "codigo TEXT UNIQUE NOT NULL, " +
            "descripcion TEXT NOT NULL, " +
            "categoria TEXT NOT NULL)",

            // Tabla de roles
            "CREATE TABLE IF NOT EXISTS roles (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
            "nombre TEXT UNIQUE NOT NULL, " +
            "descripcion TEXT NOT NULL)",

            // Tabla de relación roles-permisos
            "CREATE TABLE IF NOT EXISTS rol_permiso (" +
            "rol_id INTEGER, " +
            "permiso_codigo TEXT, " +
            "FOREIGN KEY (rol_id) REFERENCES roles(id), " +
            "FOREIGN KEY (permiso_codigo) REFERENCES permisos(codigo), " +
            "PRIMARY KEY (rol_id, permiso_codigo))",

            // Tabla de usuarios
            "CREATE TABLE IF NOT EXISTS usuarios (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
            "nombre_usuario TEXT UNIQUE NOT NULL, " +
            "clave TEXT NOT NULL, " +  // Ahora almacenará el hash BCrypt
            "rol_id INTEGER, " +
            "token TEXT, " +  // Para almacenar el token actual (opcional)
            "fecha_expiracion_token DATETIME, " +  // Para expiración del token
            "FOREIGN KEY (rol_id) REFERENCES roles(id))"
        };

        try (Statement stmt = conexion.createStatement()) {
            for (String tabla : tablas) {
                stmt.execute(tabla);
            }
            System.out.println("Tablas verificadas/creadas correctamente.");
        } catch (SQLException e) {
            System.err.println("Error creando tablas: " + e.getMessage());
        }
    }

    public Connection getConexion(){
        try{
            if (conexion == null || conexion.isClosed()){
                conectar();
            }
        } catch (SQLException e){
            System.err.println("Error verificando conexión: " + e.getMessage());
        }
        return conexion;
    }

    public void cerrarConexion(){
        try{
            if (conexion != null && !conexion.isClosed()) {
                conexion.close();
                System.out.println("Conexión a la base de datos cerrada.");
            }
        } catch (SQLException e) {
            System.err.println("Error cerrando conexión: " + e.getMessage());
        }
    }
}