package Persistencia;

import Logica.Permiso;
import java.sql.*;
import java.util.HashSet;
import java.util.Set;

public class PermisoDAO {
    private DatabaseConnection dbConnection;

    public PermisoDAO() {
        this.dbConnection = DatabaseConnection.getInstancia();
    }

    public void guardarPermiso(Permiso permiso) {
        String sql = "INSERT OR REPLACE INTO permisos (codigo, descripcion, categoria) VALUES (?, ?, ?)";
        
        try (Connection conn = dbConnection.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, permiso.getCodigo());
            pstmt.setString(2, permiso.getDescripcion());
            pstmt.setString(3, permiso.getCategoria());
            pstmt.executeUpdate();
            
        } catch (SQLException e) {
            System.err.println("Error guardando permiso: " + e.getMessage());
        }
    }

    public Permiso obtenerPermiso(String codigo) {
        String sql = "SELECT * FROM permisos WHERE codigo = ?";
        
        try (Connection conn = dbConnection.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, codigo);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return new Permiso(
                    rs.getString("codigo"),
                    rs.getString("descripcion"),
                    rs.getString("categoria")
                );
            }
        } catch (SQLException e) {
            System.err.println("Error obteniendo permiso: " + e.getMessage());
        }
        return null;
    }

    public Set<Permiso> obtenerTodosPermisos() {
        Set<Permiso> permisos = new HashSet<>();
        String sql = "SELECT * FROM permisos";
        
        try (Connection conn = dbConnection.getConexion();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                permisos.add(new Permiso(
                    rs.getString("codigo"),
                    rs.getString("descripcion"),
                    rs.getString("categoria")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error obteniendo permisos: " + e.getMessage());
        }
        return permisos;
    }

    public Set<Permiso> obtenerPermisosPorRol(int rolId) {
        Set<Permiso> permisos = new HashSet<>();
        String sql = "SELECT p.* FROM permisos p " +
                    "JOIN rol_permiso rp ON p.codigo = rp.permiso_codigo " +
                    "WHERE rp.rol_id = ?";
        
        try (Connection conn = dbConnection.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, rolId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                permisos.add(new Permiso(
                    rs.getString("codigo"),
                    rs.getString("descripcion"),
                    rs.getString("categoria")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error obteniendo permisos por rol: " + e.getMessage());
        }
        return permisos;
    }

    public void asignarPermisoARol(int rolId, String codigoPermiso) {
        String sql = "INSERT OR IGNORE INTO rol_permiso (rol_id, permiso_codigo) VALUES (?, ?)";
        
        try (Connection conn = dbConnection.getConexion();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, rolId);
            pstmt.setString(2, codigoPermiso);
            pstmt.executeUpdate();
            
        } catch (SQLException e) {
            System.err.println("Error asignando permiso a rol: " + e.getMessage());
        }
    }
}