/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.biblioteca;

/**
 *
 * @author felip
 */
import java.time.LocalDate;

public class Book {
    private String title;
    private String author;
    private String isbn;
    private String status;
    private LocalDate dueDate;


    public Book(String title, String author, String isbn) {  
        this.title = title;  
        this.author = author;  
        this.isbn = isbn;  
        this.status = "Disponible";
    }  

// FALTA: Getters y setters con validaciones
    public String getTitle(){return title;}
    public void setTitle(String title){
        if(title.isBlank()){
            throw new IllegalArgumentException("Este campo no puede estar vacío.");
        }
        this.title = title;
    }
    
    public String getAuthor(){return author;}
    public void setAuthor(String author){
        if(title.isBlank()){
            throw new IllegalArgumentException("Este campo no puede estar vacío.");
        }
        this.author = author;
    }
    
    public String getISBN(){return isbn;}
    public void setISBN(String isbn){
        if(isbn.isBlank()){throw new IllegalArgumentException("Este campo no puede estar vacío.");}
        
        if(isbn.length() != 13){throw new IllegalArgumentException("El ISBN debe ser de 13 digitos.");}
        
        this.isbn = isbn;
    }
    
    public String getStatus(){return status;}
    public void setStatus(String status){
        if(!"Disponible".equals(status)){throw new IllegalArgumentException("Opción Invalida. Seleccione Disponible o Prestado.");}
        if(!"Prestado".equals(status)){throw new IllegalArgumentException("Opción Invalida. Seleccione Disponible o Prestado.");}
        
        this.status = status;
    }
    
    public LocalDate getDueDate(){return dueDate;}

    
// FALTA: Método borrowBook() que cambie el estado
    
    public void borrowBook(){
        if(!"Disponible".equals(status)){throw new IllegalArgumentException("El libro no esta disponible.");}
        this.status = "Prestado";
    }
    
    public void returnBook(){
        if(!"Prestado".equals(status)){throw new IllegalArgumentException("Opción Invalida. El libro se encuentra Disponible.");}
        this.status = "Disponible";
    }
}
