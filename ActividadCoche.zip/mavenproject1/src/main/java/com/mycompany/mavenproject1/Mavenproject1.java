/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject1;

/**
 *
 * @author felip
 */
public class Mavenproject1 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        
//        Vehiculo v1 = new Vehiculo("ford",2023,4,900,"1ad12342h434");
//        v1.getmodelo();
//        Conductor c1 = new Conductor("trinidad","45789233",21,"1234-567890",v1);
        
//        Tractor t1 = new Tractor("valtra",2020,4,"vinatero",60);
//        t1.mostrartractor();
        
        
//        Vehiculo v2 = new Vehiculo("mercedes",2024,4);
        
        
//        Vehiculo v3 = new Vehiculo("chevrolet",2025,4);
        
//        v1.marca = "ford";
//        v2.marca = "mercedes";
//        v3.marca = "chevrolet";
//        
//        v1.modelo = 2025;
//        v2.modelo = 2025;
//        v3.modelo = 2025;
//        
//        v1.avanzar();
//        c1.mostrardatos();
//        
//        v2.avanzar();
//        v3.frenar();

    
    
    
    
    }
}
