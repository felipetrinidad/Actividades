/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author felip
 */
public class Motor {
    double potencia;
    String serie;
    
    public Motor(double potencia, String serie){
        this.potencia = potencia;
        this.serie = serie;
    }
    
    void mostrarinformacion(){
    System.out.println("Motor. Serie: " + serie + " hp: " + potencia);
    
    }
    
}
