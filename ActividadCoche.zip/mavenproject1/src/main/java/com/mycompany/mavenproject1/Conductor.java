/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author felip
 */
public class Conductor {
    
    String apellido;
    String dni;
    int edad;
    String numtelefono;
    Vehiculo vehiculo;
    
public Conductor(String apellido, String dni, int edad, String numtelefono, Vehiculo vehiculo){
    this.apellido = apellido;
    this.dni = dni;
    this.edad = edad;
    this.numtelefono = numtelefono;
    this.vehiculo = vehiculo;
}
    


void mostrardatos(){
    System.out.println("el conductor: " + apellido + " conduce: " + vehiculo.getmodelo());
}


    
void conducir(){
}
    
}
