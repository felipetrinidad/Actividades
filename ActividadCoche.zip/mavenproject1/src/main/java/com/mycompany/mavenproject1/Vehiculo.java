/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author felip
 */
public class Vehiculo {
    
    String marca;
    int modelo;
    int cantruedas;
    Motor motor;
    
    public Vehiculo(String marca, int modelo, int cantruedas, double potencia, String serie){
    this.marca = marca;
    this.modelo = modelo;
    this.cantruedas = cantruedas;
    this.motor = new Motor(potencia, serie);
    }
    
    public String getmodelo(){
        return marca + " " + modelo;
    }
    
    void avanzar(){
        System.out.println("el auto avanzo" + " " + marca + " " + modelo);
    }

    void acelerar(){
        System.out.println("el auto acelero" + marca + modelo);
    }

    void frenar(){
        System.out.println("el auto freno" + marca + modelo);
    }
    
    void mostrarmotor(){
//        System.out.println("Motor: " + );
        motor.mostrarinformacion();
    }
}
