/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author felip
 */
public class Tractor extends Vehiculo{
    String tipo;
    int hp;
    
    public Tractor(String marca, int modelo, int cantruedas,double potencia, String serie, String tipo, int hp) {
        super(marca, modelo, cantruedas, potencia, serie);
        this.tipo = tipo;
        this.hp = hp;
    }
    
    
public void mostrartractor(){
    System.out.println("info del tractor: " + marca +" "+ modelo +" "+ tipo +" "+ hp +" hp");
}
    
}
