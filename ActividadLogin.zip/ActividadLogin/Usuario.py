import bcrypt
from Rol import Rol

class Usuario:
    def __init__(self, nombreUsuario, clave, Rol):
        self.nombreUsuario = nombreUsuario
        self.clave = self.encriptarClave(clave)
        self.rol = Rol
    
    #getters
    def getNombre(self):
        return self.nombreUsuario
        
    def getRol(self):
        return self.rol
        
    #Hashing
    def validarClave(self, claveIngresada):
        return bcrypt.checkpw(claveIngresada.encode('utf-8'), self.clave)
    
    def encriptarClave(self, clave):
        return bcrypt.hashpw(clave.encode('utf-8'), bcrypt.gensalt())
    