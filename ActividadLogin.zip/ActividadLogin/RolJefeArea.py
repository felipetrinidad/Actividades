from Rol import Rol

class RolJefeArea(Rol):
    def __init__(self):
        super().__init__("Jefe de Area", ["LECTURA", "EDICION"])
    
    def autorizar(self, nombreUsuario):
        print("\n--- Panel Jefatura ---")
        print("Permisos: LECTURA, EDICIÓN")
        print("Puede: Editar documentos del área, revisar indicadores")