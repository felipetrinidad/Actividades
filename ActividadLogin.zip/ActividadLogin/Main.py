from FabricaRoles import FabricaRoles
from FabricaUsuarios import FabricaUsuarios

from SistemaLogin import SistemaLogin



class Main:
    
    if __name__ == "__main__":
        # Crear el sistema de login
        sistema = SistemaLogin()
        
        
        # Registro de usuarios
        sistema.registrar_usuario(FabricaUsuarios.crearUsuario("Personal","feli", "1234"))
        sistema.registrar_usuario(FabricaUsuarios.crearUsuario("Administrador","ana", "clave123"))
        sistema.registrar_usuario(FabricaUsuarios.crearUsuario("Director","pedro", "director12"))
        sistema.registrar_usuario(FabricaUsuarios.crearUsuario("Supervisor","laura", "superv2025"))
        
        
        # Interfaz de login
        print("---- SISTEMA DE INICIO DE SESION ----")
        
        
        
        # Primer inicio de sesión
        usuario = sistema.autenticar("feli", "1234")
        if usuario:
            sistema.autorizar(usuario)

        # Intento de segundo inicio de sesión (mismo usuario)
        print("\n--- Segundo inicio de sesión ---")
        usuario = sistema.autenticar("feli", "1234")
        if usuario:
            sistema.autorizar(usuario)

        # Ver sesiones activas
        sistema.listarSesionesActivas()

        # Cerrar sesión
        sistema.cerrarSesion("feli")
        sistema.listarSesionesActivas()
        
        
        while True:
            nombre = input("\nUsuario: ").strip()
            clave = input("Contraseña: ").strip()
            #print(f"\n {Usuario.encriptarClave(nombre,clave)}")

            usuario_autenticado = sistema.autenticar(nombre, clave)

            if usuario_autenticado is not None:
                sistema.autorizar(usuario_autenticado)
                break
            else:
                print("\nCredenciales incorrectas. Intente nuevamente.")
                
