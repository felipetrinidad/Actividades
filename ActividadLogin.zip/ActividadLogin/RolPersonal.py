from Rol import Rol

class RolPersonal(Rol):
    def __init__(self):
       super().__init__("Personal", ["LECTURA"])
        
    def autorizar(self, nombreUsuario):
        print("\n--- Panel Personal ---")
        print("Permisos: LECTURA")
        print("Puede: Consultar información, ver reportes básicos")