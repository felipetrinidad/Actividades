from SistemaManager import SistemaManager


class SistemaLogin:
    def __init__(self):
        self.usuarios = []
        self.sistemaManager = SistemaManager()
        
        
    def registrar_usuario(self, usuario):
        self.usuarios.append(usuario)
    
        
    def autenticar(self, nombreUsuario, clave):
        #Se verifica que el usuario no tenga sesiones activas (singleton)
        if self.sistemaManager.verUserActivo(nombreUsuario):
            print(f"Usuario: {nombreUsuario} ya tiene sesiones activas. \nSe procede a cerrarlas automaticamente.\n")
            self.sistemaManager.cerrarSesion(nombreUsuario)
        
        #Se verifica que exista el usuario y se comprueba su contraseña
        for usuario in self.usuarios:
            if (usuario.getNombre() == nombreUsuario and 
                usuario.validarClave(clave)):
                
                #se registra la sesion en el singleton
                self.sistemaManager.iniciarSesion(usuario)
                return usuario
        return None
    
    
    def autorizar(self, usuario):
        #Se verifica que no tenga sesiones activas previas
        if not self.sistemaManager.verUserActivo(usuario.getNombre()):
            raise ValueError(f"Error: {usuario.getNombre()} ya tiene una sesion activa.")
        
        rol = usuario.getRol()
        rol.autorizar(usuario.getNombre())
        
        print(f"\nBienvenido(a), {usuario.getNombre()}!")
    
    def cerrarSesion(self, nombreUsuario):
        self.sistemaManager.cerrarSesion(nombreUsuario)
        
    def listarSesionesActivas(self):
        sesiones = self.sistemaManager.getSesionesActivas()
        
        print(f"Sesiones Activas: {len(sesiones)}")
        for user, datos in sesiones.items():
            tiempo = datos['login_time'].strftime("%H:%M:%S")
            print(f"  - {user} (desde {tiempo})")