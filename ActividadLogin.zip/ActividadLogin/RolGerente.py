from Rol import Rol

class RolGerente(Rol):
    def __init__(self):
        super().__init__("Gerente", ["LECTURA", "EDICION", "APROBACION"])
        
    def autorizar(self, nombreUsuario):
        print("\n--- Panel de Gerencia ---")
        print("Permisos: LECTURA, EDICIÓN, APROBACIÓN")
        print("Puede: Aprobar solicitudes, editar reportes, generar informes")