from Rol import Rol

class RolDirector(Rol):
    def __init__(self):
        super().__init__("Director", ["LECTURA", "EDICIÓN", "APROBACION", "DECISION"])
        
    def autorizar(self, nombreUsuario):
        print("\n--- Panel de Dirección ---")
        print("Permisos: LECTURA, EDICIÓN, APROBACIÓN, DECISIÓN")
        print("Puede: Tomar decisiones estratégicas, aprobar presupuestos")