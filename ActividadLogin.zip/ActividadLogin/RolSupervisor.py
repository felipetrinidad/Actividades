from Rol import Rol

class RolSupervisor(Rol):
    def __init__(self):
        super().__init__("Supervisor", ["LECTURA", "CONTROL"])
        
    def autorizar(self, nombreUsuario):
        print("\n--- Panel Supervisión ---")
        print("Permisos: LECTURA, CONTROL")
        print("Puede: Supervisar operaciones, generar reportes de control")