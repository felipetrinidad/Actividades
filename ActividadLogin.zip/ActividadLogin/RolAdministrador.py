from Rol import Rol

class RolAdministrador(Rol):
    def __init__(self):
        super().__init__("Administrador del Sistema", ["GESTION_TOTAL"])
        
    def autorizar(self, nombreUsuario):
        print("\n--- Acceso completo al sistema ---")
        print("Permisos: GESTION_TOTAL")
        print("Puede: Gestionar usuarios, configurar sistema, acceso total")