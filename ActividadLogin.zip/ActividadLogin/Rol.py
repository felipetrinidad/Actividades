from abc import ABC, abstractmethod

class Rol(ABC):
    def __init__(self, nombre, permisos):
        self.nombre = nombre
        self.permisos = permisos
        
    def tienePermiso(self, permiso):
        return permiso in self.permisos
    
    def getNombre(self):
        return self.nombre
    
    @abstractmethod
    def autorizar(self, nombreUsuario):
        pass