from RolPersonal import RolPersonal
from RolJefeArea import RolJefeArea
from RolGerente import RolGerente
from RolDirector import RolDirector
from RolSupervisor import RolSupervisor
from RolAdministrador import RolAdministrador

class FabricaRoles:
    @staticmethod
    def crearRol(tipoRol):
        tipoRol = tipoRol.lower().strip()
        
        if tipoRol == "personal":
            return RolPersonal()
        elif tipoRol == "jefe de area" or tipoRol == "jefe de área":
            return RolJefeArea()
        elif tipoRol == "gerente":
            return RolGerente()
        elif tipoRol == "director":
            return RolDirector()
        elif tipoRol == "supervisor":
            return RolSupervisor
        elif tipoRol == "administrador":
            return RolAdministrador
        else:
            raise ValueError(f"Tipo de rol desconocido: {tipoRol}")