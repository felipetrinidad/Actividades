import bcrypt

from Rol import Rol
from datetime import datetime, timedelta

class SistemaManager:
    instancia = None
    sesiones_activas = {}
    
    def __new__(cls):
        if cls.instancia is None:
            cls.instancia = super(SistemaManager, cls).__new__(cls)
        return cls.instancia
    
    
    #Iniciar Sesión
    def iniciarSesion(self, usuario):
        user = usuario.getNombre()
        
        #Se cierra sesiones previas
        if user in self.sesiones_activas:
            self.cerrarSesion(user)
        
        #Se registra nueva sesion
        self.sesiones_activas[user] = {
            "usuario": user,
            "login_time": datetime.now()
        }
        
        print(f"Sesion iniciciada \n¡Bienvenido {user}!")
            
    
    #Cerrar Sesion
    def cerrarSesion(self, user):
        if user in self.sesiones_activas:
            del self.sesiones_activas[user]
            print(f"Sesion Cerrada para {user}")
    
    
    #Verificar si el Usuario tiene sesiones activas
    def verUserActivo(self, user):
        return user in self.sesiones_activas
    
    
    # Getters
    def getUsuarioActivo(self, user):
        return self.sesiones_activas.get(user, {}).get("usuario")
    
    def getSesionesActivas(self):
        return self.sesiones_activas.copy()
    
    