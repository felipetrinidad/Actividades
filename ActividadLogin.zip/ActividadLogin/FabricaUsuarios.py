from Usuario import Usuario
from FabricaRoles import FabricaRoles

class FabricaUsuarios:
    @staticmethod
    def crearUsuario(tipoUsuario, nombreUsuario, clave):
        rol = FabricaRoles.crearRol(tipoUsuario)
        
        return Usuario(nombreUsuario, clave, rol)