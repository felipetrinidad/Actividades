package logica;

public class CursoEnVivo extends Curso{
    // Atributos privados
    private String horario;
    private String enlace;

    //Constructor
    public CursoEnVivo(String nombreCurso, String nombreProfesor, int duracionHoras, EstrategiaEvaluacion estrategiaEvaluacion, String horario, String enlace){
        super(nombreCurso, nombreProfesor, duracionHoras, estrategiaEvaluacion);
        this.horario = horario;
        this.enlace = enlace;
    }

    // Gettters y Setters (para acceder/modificar informacion)
    public String getHorario() {return horario;}
    public void setHorario(String horario) {this.horario = horario;}

    public String getEnlace() {return enlace;}
    public void setEnlace(String enlace) {this.enlace = enlace;}

    // Metodo: Unirse a una Clase:
    public void unirseClase(Estudiante estudiante){
        System.out.println("Alumno: " + estudiante.getNombreEstudiante() +
                "\nUniendose en: " + getNombreCurso() +
                "\nEnlace: " + getEnlace() +
                "\nHorario: " + getHorario() + "\n");
    }


    // Comportamientos comunes
    @Override
    void inscribirAlumno(Estudiante estudiante) {
        System.out.println("Inscribiendo a: " + estudiante.getNombreEstudiante() + " en el curso " + getNombreCurso() + "\n");
        inscribir(estudiante);
    }

    @Override
    void emitirCertificado(Estudiante estudiante) {
        if (evaluar(estudiante)){
            System.out.println("Certificado del Curso " + getNombreCurso()
                    + "emitido para el Estudiante: " + estudiante.getNombreEstudiante() + "\n");
        }else {
            System.out.println(estudiante.getNombreEstudiante() + " no ha alcanzado la nota para Certificarse." + "\n");
        }
    }
}
