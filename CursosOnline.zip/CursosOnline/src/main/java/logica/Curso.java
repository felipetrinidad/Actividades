package logica;
import java.util.HashMap;
import java.util.Map;
public abstract class Curso {
    // Atributos privados (Encapsulamiento)
    private String nombreCurso;
    private String nombreProfesor;
    private int duracionHoras;
    private EstrategiaEvaluacion estrategiaEvaluacion;
    private Map<Estudiante, Double> notas = new HashMap<>();

    // Constructor
    public Curso(String nombreCurso, String nombreProfesor, int duracionHoras, EstrategiaEvaluacion estrategiaEvaluacion){
        this.nombreCurso = nombreCurso;
        this.nombreProfesor = nombreProfesor;
        this.duracionHoras = duracionHoras;
        this.estrategiaEvaluacion = estrategiaEvaluacion;
    }

    // Getters y Setters (para acceder/modificar datos encapsulados)
    public String getNombreCurso() {return nombreCurso;}
    public void setNombreCurso(String nombreCurso) {this.nombreCurso = nombreCurso;}

    public String getNombreProfesor() {return nombreProfesor;}
    public void setNombreProfesor(String nombreProfesor) {this.nombreProfesor = nombreProfesor;}

    public int getDuracionHoras() {return duracionHoras;}
    public void setDuracionHoras(int duracionHoras) {this.duracionHoras = duracionHoras;}

    public EstrategiaEvaluacion getEstrategiaEvaluacion() {return estrategiaEvaluacion;}
    public void setEstrategiaEvaluacion(EstrategiaEvaluacion estrategiaEvaluacion) {this.estrategiaEvaluacion = estrategiaEvaluacion;}

    public Double getNotas(Estudiante estudiante) {return notas.get(estudiante);}
    public void setNotas(Estudiante estudiante, double nota) { notas.put(estudiante, nota); }

    //Agregar Estudiante a la lista de alumnos de Cursos
    public void inscribir(Estudiante estudiante){ notas.putIfAbsent(estudiante,0.0);}

    // Evaluar Estudiante
    public boolean evaluar(Estudiante estudiante){
        return estrategiaEvaluacion.evaluar(this, estudiante);
    }

    // Comportamientos Comunes:
    abstract void inscribirAlumno(Estudiante estudiante);
    abstract void emitirCertificado(Estudiante estudiante);
}
