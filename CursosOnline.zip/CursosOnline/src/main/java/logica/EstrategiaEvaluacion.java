package logica;

public interface EstrategiaEvaluacion {
    // Patron de Diseño: Strategy
    boolean evaluar(Curso curso, Estudiante estudiante);
}
