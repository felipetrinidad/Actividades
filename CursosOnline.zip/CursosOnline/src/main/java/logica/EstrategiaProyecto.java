package logica;
public class EstrategiaProyecto implements EstrategiaEvaluacion{
    @Override
    public boolean evaluar(Curso curso, Estudiante estudiante) {
        Double nota = curso.getNotas(estudiante);
        System.out.println("Evaluando a: " + estudiante.getNombreEstudiante() + " con Estrategias de Proyectos\n");
        return nota != null && nota >= 60;
    }
}
