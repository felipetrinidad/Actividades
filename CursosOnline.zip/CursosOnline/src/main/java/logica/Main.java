package logica;
public class Main {
    public static void main(String[] args){
        // Se instancia un ALumno
        Estudiante felipe = new Estudiante("Felipe", "1");
        // Estrategias de Evaluación:
        EstrategiaExamen examen = new EstrategiaExamen();
        EstrategiaProyecto proyecto = new EstrategiaProyecto();
        //Curso en Vivo
        CursoEnVivo cursoEnVivo = FabricaCursos.crearCursoEnVivo("Paradigmas II", "Profesor 1",
                15, examen, "15:00 - 18:00", "cursoFundamentosProgramacion.com.ar");
        // Inscibir Estudiante al curso:
        cursoEnVivo.inscribirAlumno(felipe);
        // Unirse a una clase:
        cursoEnVivo.unirseClase(felipe);
        // Definir Notas
        cursoEnVivo.setNotas(felipe, 50.0);
        //Intentar Emitir Certificado
        cursoEnVivo.emitirCertificado(felipe);
        // Definir siguiente nota para poder emitir certificado
        cursoEnVivo.setNotas(felipe, 60.0);
        cursoEnVivo.emitirCertificado(felipe);
    }
}
