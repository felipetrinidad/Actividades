package logica;

public class CursoGrabado extends Curso{
    //Atributo Encapsulado
    private boolean permitirDescarga;

    //Constructor
    public CursoGrabado(String nombreCurso, String nombreProfesor, int duracionHoras,  EstrategiaEvaluacion estrategiaEvaluacion, boolean permitirDescarga) {
        super(nombreCurso, nombreProfesor, duracionHoras, estrategiaEvaluacion);
        this.permitirDescarga = permitirDescarga;
    }

    //Metodo: Descargar Curso
    public void descargarCurso(){
        if (permitirDescarga){
            System.out.println("Descargando contenido de: " + getNombreCurso());
        }else {
            System.out.println("Descarga no permitida para: " + getNombreCurso());
        }
    }

    @Override
    void inscribirAlumno(Estudiante estudiante) {
        System.out.println("Inscribiendo a: " + estudiante + " en el curso " + getNombreCurso());
        inscribir(estudiante);
    }

    @Override
    void emitirCertificado(Estudiante estudiante) {
        if (evaluar(estudiante)){
            System.out.println("Certificado del Curso " + getNombreCurso()
                    + "emitido para el Estudiante: " + estudiante.getNombreEstudiante());
        }else {
            System.out.println(estudiante.getNombreEstudiante() + " no ha alcanzado la nota para Certificarse.");
        }
    }
}