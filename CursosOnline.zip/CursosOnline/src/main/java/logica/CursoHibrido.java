package logica;

public class CursoHibrido extends Curso{
    // Atributos Encapsulados
    private CursoEnVivo parteEnVivo;
    private CursoGrabado parteGrabada;

    // Constructor
    public CursoHibrido(String nombreCurso, String nombreProfesor, int duracionHoras, EstrategiaEvaluacion estrategiaEvaluacion, CursoEnVivo parteEnVivo, CursoGrabado parteGrabada) {
        super(nombreCurso, nombreProfesor, duracionHoras, estrategiaEvaluacion);
        this.parteEnVivo = parteEnVivo;
        this.parteGrabada = parteGrabada;
    }

    @Override
    void inscribirAlumno(Estudiante estudiante) {
        System.out.println("Inscribiendo a: " + estudiante + " en el curso " + getNombreCurso());
        inscribir(estudiante);
    }

    @Override
    void emitirCertificado(Estudiante estudiante) {
        if (evaluar(estudiante)){
            System.out.println("Certificado del Curso " + getNombreCurso()
                    + "emitido para el Estudiante: " + estudiante.getNombreEstudiante());
        }else {
            System.out.println(estudiante.getNombreEstudiante() + " no ha alcanzado la nota para Certificarse.");
        }
    }
}