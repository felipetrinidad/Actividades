package logica;

public class Estudiante {
    private String nombreEstudiante;
    private String dni;

    public Estudiante(String nombreEstudiante, String dni){
        this.nombreEstudiante = nombreEstudiante;
        this.dni = dni;
    }

    //Getters y Setters:

    public String getNombreEstudiante() {return nombreEstudiante;}
    public void setNombreEstudiante(String nombreEstudiante) {this.nombreEstudiante = nombreEstudiante;}

    public String getDni() {return dni;}
    public void setDni(String dni) {this.dni = dni;}
}
