package logica;

public class FabricaCursos {
    // Patron de Diseño: Factory

    public static CursoEnVivo crearCursoEnVivo(String nombreCurso, String nombreProfesor, int duracionHoras, EstrategiaEvaluacion estrategiaEvaluacion, String horario, String enlace){
        return new CursoEnVivo(nombreCurso, nombreProfesor, duracionHoras, estrategiaEvaluacion, horario, enlace);
    }

    public CursoGrabado crearCursoGrabado(String nombreCurso, String nombreProfesor, int duracionHoras, EstrategiaEvaluacion estrategiaEvaluacion, boolean permitirDescarga){
        return new CursoGrabado(nombreCurso, nombreProfesor, duracionHoras, estrategiaEvaluacion, permitirDescarga);
    }

    public CursoHibrido crearCursoHibrido (String nombreCurso, String nombreProfesor, int duracionHoras, EstrategiaEvaluacion estrategiaEvaluacion, CursoEnVivo parteEnVivo, CursoGrabado parteGrabada){
        return new CursoHibrido(nombreCurso, nombreProfesor, duracionHoras, estrategiaEvaluacion, parteEnVivo, parteGrabada);
    }
}
