package logica;
public class EstrategiaExamen implements EstrategiaEvaluacion{
    @Override
    public boolean evaluar(Curso curso, Estudiante estudiante) {
        Double nota = curso.getNotas(estudiante);
        System.out.println("Evaluando a: " + estudiante.getNombreEstudiante() + " con Estrategia de Examen.");
        return nota != null && nota >= 70;
    }
}
